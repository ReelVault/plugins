// @bun
// plugins/notify-webhook/index.ts
import { definePlugin } from "@reelvault/sdk/plugin";

// plugins/notify-webhook/config.ts
import { defineConfig, field } from "@reelvault/sdk/plugin";
var config = defineConfig({
  webhookUrl: field.secret({
    label: { en: "Webhook URL", pl: "Adres webhooka" },
    description: {
      en: "Every notification is POSTed as JSON to this URL.",
      pl: "Ka\u017Cde powiadomienie jest wysy\u0142ane metod\u0105 POST w formacie JSON na ten adres."
    },
    default: ""
  }),
  authorizationHeader: field.secret({
    label: { en: "Authorization header", pl: "Nag\u0142\xF3wek Authorization" },
    description: {
      en: "Optional value sent as the Authorization header (e.g. a bearer token).",
      pl: "Opcjonalna warto\u015B\u0107 wysy\u0142ana w nag\u0142\xF3wku Authorization (np. token bearer)."
    },
    default: ""
  }),
  notifyNewEpisodes: field.boolean({ label: { en: "New episodes", pl: "Nowe odcinki" }, default: true }),
  notifySystem: field.boolean({
    label: { en: "System and plugin notifications", pl: "Powiadomienia systemowe i wtyczek" },
    description: {
      en: "Everything that is not a new-episode notification.",
      pl: "Wszystko, co nie jest powiadomieniem o nowym odcinku."
    },
    default: true
  })
});

// plugins/notify-webhook/index.ts
var notify_webhook_default = definePlugin(config, {
  setup(host) {
    host.notificationChannels.register({
      id: "notify-webhook",
      deliver: async (notification) => {
        if (!host.config.webhookUrl)
          return;
        if (!host.config.notifyNewEpisodes && notification.type === "new_episode")
          return;
        if (!host.config.notifySystem && notification.type !== "new_episode")
          return;
        const response = await host.http.fetch(host.config.webhookUrl, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            ...host.config.authorizationHeader ? { authorization: host.config.authorizationHeader } : {}
          },
          body: JSON.stringify({
            id: notification.id,
            type: notification.type,
            title: notification.title,
            message: notification.message ?? null,
            link: notification.link ?? null,
            data: notification.data ?? {}
          })
        });
        if (!response.ok) {
          host.logger.warn("Webhook delivery rejected", { status: response.status, type: notification.type });
        }
      }
    });
    host.logger.info("Notify Webhook plugin initialized");
  }
});
export {
  notify_webhook_default as default
};
