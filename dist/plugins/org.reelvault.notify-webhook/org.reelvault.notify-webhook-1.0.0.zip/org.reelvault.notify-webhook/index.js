// @bun
// plugins/notify-webhook/index.ts
import { definePlugin } from "@reelvault/sdk/plugin";

// plugins/notify-webhook/config.ts
import { defineConfig, field } from "@reelvault/sdk/plugin";
var config = defineConfig({
  webhookUrl: field.secret({
    label: "Webhook URL",
    description: "Every notification is POSTed as JSON to this URL.",
    default: ""
  }),
  authorizationHeader: field.secret({
    label: "Authorization header",
    description: "Optional value sent as the Authorization header (e.g. a bearer token).",
    default: ""
  }),
  notifyNewEpisodes: field.boolean({ label: "New episodes", default: true }),
  notifySystem: field.boolean({
    label: "System and plugin notifications",
    description: "Everything that is not a new-episode notification.",
    default: true
  })
});

// plugins/notify-webhook/index.ts
var notify_webhook_default = definePlugin(config, {
  setup(host) {
    host.notificationChannels.register({
      id: "notify-webhook",
      deliver: async (notification) => {
        if (!host.config.webhookUrl)
          return;
        if (!host.config.notifyNewEpisodes && notification.type === "new_episode")
          return;
        if (!host.config.notifySystem && notification.type !== "new_episode")
          return;
        const response = await host.http.fetch(host.config.webhookUrl, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            ...host.config.authorizationHeader ? { authorization: host.config.authorizationHeader } : {}
          },
          body: JSON.stringify({
            id: notification.id,
            type: notification.type,
            title: notification.title,
            message: notification.message ?? null,
            link: notification.link ?? null,
            data: notification.data ?? {}
          })
        });
        if (!response.ok) {
          host.logger.warn("Webhook delivery rejected", { status: response.status, type: notification.type });
        }
      }
    });
    host.logger.info("Notify Webhook plugin initialized");
  }
});
export {
  notify_webhook_default as default
};
