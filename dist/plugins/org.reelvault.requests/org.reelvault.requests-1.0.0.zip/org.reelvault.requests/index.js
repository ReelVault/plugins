// @bun
// plugins/media-requests/index.ts
import { definePlugin } from "@reelvault/sdk/plugin";

// plugins/media-requests/config.ts
import { defineConfig, field } from "@reelvault/sdk/plugin";
var config = defineConfig({
  autoApprove: field.boolean({
    label: "Automatyczne zatwierdzanie",
    description: "Nowe pro\u015Bby u\u017Cytkownik\xF3w s\u0105 zatwierdzane automatycznie, bez udzia\u0142u administratora.",
    default: false
  }),
  notifyOnAvailable: field.boolean({
    label: "Powiadomienia o dost\u0119pno\u015Bci",
    description: "Wysy\u0142a powiadomienie w aplikacji, gdy \u017C\u0105dany film lub serial trafi do biblioteki.",
    default: true
  }),
  maxActiveRequestsPerUser: field.number({
    label: "Aktywne pro\u015Bby na u\u017Cytkownika",
    description: "Maksymalna liczba oczekuj\u0105cych, zatwierdzonych lub realizowanych pr\xF3\u015Bb jednego u\u017Cytkownika.",
    default: 10,
    min: 1,
    max: 100,
    step: 1
  }),
  showDashboardSection: field.boolean({
    label: "Sekcja \u201EWkr\xF3tce w bibliotece\u201D",
    description: "Wy\u015Bwietla na stronie g\u0142\xF3wnej sekcj\u0119 z zatwierdzonymi i realizowanymi pro\u015Bbami.",
    default: true
  })
});

// plugins/media-requests/src/availability.ts
class AvailabilityService {
  host;
  manager;
  constructor(host, manager) {
    this.host = host;
    this.manager = manager;
  }
  async resolve(providerId, mediaType, items) {
    const externalIds = [...new Set(items.map((item) => item.externalId).filter((id) => id.length > 0))];
    const library = new Map;
    if (externalIds.length > 0) {
      try {
        const rows = await this.host.metadata.findManyByExternalIds(providerId, externalIds, mediaType);
        for (const row of rows)
          library.set(row.externalId, row);
      } catch (error) {
        this.host.logger.warn("Library availability lookup failed", { providerId, error });
      }
    }
    const requests = await this.manager.getAllRequests();
    const byExternal = new Map;
    const byTitle = new Map;
    for (const request of requests) {
      const externalKey = this.externalKey(request.providerId, request.externalId ?? request.tmdbId ?? request.imdbId);
      if (externalKey)
        byExternal.set(externalKey, request);
      byTitle.set(this.titleKey(request.mediaType, request.title, request.year), request);
    }
    const result = new Map;
    for (const item of items) {
      const libraryMatch = library.get(item.externalId);
      if (libraryMatch?.hasFiles) {
        result.set(item.externalId, { state: "available", metadataId: libraryMatch.metadataId });
        continue;
      }
      const externalKey = this.externalKey(providerId, item.externalId);
      const year = item.releaseDate ? Number(item.releaseDate.slice(0, 4)) : undefined;
      const request = (externalKey ? byExternal.get(externalKey) : undefined) ?? byTitle.get(this.titleKey(mediaType, item.title, year));
      result.set(item.externalId, {
        state: request ? request.status : "none",
        requestId: request?.id,
        metadataId: libraryMatch?.metadataId
      });
    }
    return result;
  }
  externalKey(providerId, externalId) {
    if (!externalId)
      return;
    return `${providerId ?? "tmdb"}:${externalId}`;
  }
  titleKey(mediaType, title, year) {
    return `${mediaType}:${title.trim().toLowerCase()}:${year ?? ""}`;
  }
}

// plugins/media-requests/src/availability-checker.ts
var ACTIVE_STATUSES = new Set(["pending", "approved", "in_progress"]);
var WORD_CHAR = /[\p{L}\p{N}]/u;
var YEAR_PATTERN = /(?:19|20)\d{2}/g;
function providerNamespace(request) {
  if (request.providerId)
    return request.providerId;
  if (request.tmdbId)
    return "tmdb";
  if (request.imdbId)
    return "imdb";
  return;
}
function normalizeForMatch(value) {
  return value.toLowerCase().replace(/[._\-[\]()]+/g, " ").replace(/\s+/g, " ").trim();
}
function containsPhrase(haystack, needle) {
  if (!needle)
    return false;
  let start = haystack.indexOf(needle);
  while (start !== -1) {
    const before = start === 0 ? "" : haystack[start - 1];
    const end = start + needle.length;
    const after = end >= haystack.length ? "" : haystack[end];
    if (!(before && WORD_CHAR.test(before) || after && WORD_CHAR.test(after)))
      return true;
    start = haystack.indexOf(needle, start + 1);
  }
  return false;
}
function fileMatchesRequest(request, fileName) {
  const title = normalizeForMatch(request.title);
  if (!title)
    return false;
  const name = normalizeForMatch(fileName);
  if (!containsPhrase(name, title))
    return false;
  if (!request.year)
    return true;
  const years = name.match(YEAR_PATTERN);
  return !years || years.includes(String(request.year));
}

class AvailabilityChecker {
  host;
  manager;
  constructor(host, manager) {
    this.host = host;
    this.manager = manager;
  }
  async checkMetadata(metadataId) {
    let fulfilledCount = 0;
    if (!metadataId)
      return fulfilledCount;
    const metadata = await this.host.metadata.get(metadataId);
    if (!metadata?.title)
      return fulfilledCount;
    const activeRequests = (await this.manager.getAllRequests()).filter((r) => ACTIVE_STATUSES.has(r.status));
    if (activeRequests.length === 0)
      return fulfilledCount;
    const metaTitleNormalized = metadata.title.trim().toLowerCase();
    const metaYear = metadata.releaseDate ? new Date(metadata.releaseDate).getFullYear() : undefined;
    const externalIds = new Map(metadata.externalIds.map((identity) => [identity.providerId, identity.externalId]));
    for (const req of activeRequests) {
      const reqTitleNormalized = req.title.trim().toLowerCase();
      const providerId = providerNamespace(req);
      const externalId = req.externalId ?? req.tmdbId ?? req.imdbId;
      let isMatch = false;
      if (providerId && externalId && externalIds.get(providerId) === externalId) {
        isMatch = true;
      } else if (metaTitleNormalized === reqTitleNormalized) {
        if (!(req.year && metaYear) || req.year === metaYear) {
          isMatch = true;
        }
      }
      if (isMatch) {
        await this.manager.markAsAvailable(req, metadataId);
        fulfilledCount++;
      }
    }
    return fulfilledCount;
  }
  async syncAllRequests() {
    const activeRequests = (await this.manager.getAllRequests()).filter((r) => ACTIVE_STATUSES.has(r.status));
    this.host.logger.info(`Starting synchronization of ${activeRequests.length} media requests`);
    let fulfilled = 0;
    const unresolved = [];
    for (const request of activeRequests) {
      const providerId = providerNamespace(request);
      const externalId = request.externalId ?? request.tmdbId ?? request.imdbId;
      if (!(providerId && externalId)) {
        unresolved.push(request);
        continue;
      }
      const match = await this.findLibraryEntry(providerId, externalId, request.mediaType);
      if (match?.hasFiles && match.metadataId) {
        await this.manager.markAsAvailable(request, match.metadataId);
        fulfilled++;
      } else {
        unresolved.push(request);
      }
    }
    if (unresolved.length > 0) {
      const files = await this.host.media.listAllMediaFiles();
      for (const file of files) {
        if (unresolved.length === 0)
          break;
        const index = unresolved.findIndex((request) => fileMatchesRequest(request, file.fileName));
        if (index === -1)
          continue;
        const request = unresolved[index];
        if (!request)
          continue;
        await this.manager.markAsAvailable(request, file.mediaFileId);
        unresolved.splice(index, 1);
        fulfilled++;
      }
    }
    return {
      checked: activeRequests.length,
      fulfilled
    };
  }
  async findLibraryEntry(providerId, externalId, mediaType) {
    try {
      return await this.host.metadata.findByExternalId(providerId, externalId, mediaType);
    } catch (error) {
      this.host.logger.warn("Library lookup failed during request sync", { providerId, externalId, error });
      return null;
    }
  }
}

// plugins/media-requests/src/discover-service.ts
function releaseYear(releaseDate) {
  if (!releaseDate)
    return;
  const year = Number(releaseDate.slice(0, 4));
  return Number.isFinite(year) && year > 0 ? year : undefined;
}
var TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p";
var ABSOLUTE_URL = /^https?:\/\//i;
var TMDB_ORIGINAL_SEGMENT = "/t/p/original/";
function posterImageUrl(path, size = "w185") {
  if (!path)
    return;
  if (ABSOLUTE_URL.test(path)) {
    return path.includes(TMDB_ORIGINAL_SEGMENT) ? path.replace(TMDB_ORIGINAL_SEGMENT, `/t/p/${size}/`) : path;
  }
  if (path.startsWith("/"))
    return `${TMDB_IMAGE_BASE}/${size}${path}`;
  return;
}

class DiscoverService {
  providers;
  availability;
  constructor(providers, availability) {
    this.providers = providers;
    this.availability = availability;
  }
  async discover(query) {
    const page = await this.providers.discover(query);
    if (!page) {
      return { page: query.page, totalPages: 0, totalResults: 0, items: [], unsupported: true };
    }
    const items = await this.toCards(page.providerId, query.type, page.items);
    return {
      providerId: page.providerId,
      page: page.page,
      totalPages: page.totalPages,
      totalResults: page.totalResults,
      items,
      unsupported: false
    };
  }
  async genres(type, providerId) {
    const genres = await this.providers.getGenres(type, providerId);
    return genres.map((genre) => this.toGenre(genre.id, genre.name));
  }
  async seasonDetails(providerId, externalId, seasonNumber) {
    const season = await this.providers.getSeasonDetails(providerId, externalId, seasonNumber);
    if (!season)
      return null;
    return {
      number: Number(season.seasonNumber),
      name: season.name,
      overview: season.overview,
      airDate: season.airDate,
      posterPath: season.posterPath,
      episodes: (season.episodes ?? []).map((episode) => ({
        number: Number(episode.episodeNumber),
        name: episode.name,
        overview: episode.overview,
        airDate: episode.airDate,
        thumbnailPath: episode.thumbnailPath
      }))
    };
  }
  async search(type, query) {
    const groups = await this.providers.search(type, query);
    const cards = [];
    const seen = new Set;
    for (const group of groups) {
      const groupCards = await this.toCards(group.providerId, type, group.results);
      for (const card of groupCards) {
        if (seen.has(card.externalId))
          continue;
        seen.add(card.externalId);
        cards.push(card);
      }
    }
    return { items: cards };
  }
  async details(providerId, type, externalId) {
    const metadata = await this.providers.getDetails(providerId, type, externalId);
    if (!metadata)
      return null;
    const availability = await this.availability.resolve(providerId, type, [
      { externalId, title: metadata.title, releaseDate: metadata.releaseDate }
    ]);
    const info = availability.get(externalId);
    return {
      ...this.baseCard(providerId, type, metadata, info),
      title: metadata.title,
      backdropPath: metadata.backdropPath,
      tagline: metadata.tagline,
      overview: metadata.overview,
      releaseDate: metadata.releaseDate,
      voteAverage: metadata.voteAverage,
      voteCount: metadata.voteCount,
      popularity: metadata.popularity,
      providerStatus: metadata.status,
      originalTitle: metadata.originalTitle,
      genres: (metadata.genres ?? []).map((genre) => this.toGenre(genre.id, genre.name)),
      cast: (metadata.cast ?? []).slice(0, 24).map((member) => ({
        id: member.id,
        name: member.name,
        character: member.character,
        profilePath: member.profilePath
      })),
      crew: (metadata.crew ?? []).slice(0, 24).map((member) => ({
        id: member.id,
        name: member.name,
        job: member.job,
        department: member.department
      })),
      seasons: (metadata.seasons ?? []).filter((season) => Number(season.seasonNumber) !== 0 || (season.episodes?.length ?? 0) > 0).map((season) => ({
        number: Number(season.seasonNumber),
        name: season.name ?? `Season ${season.seasonNumber}`,
        episodeCount: season.episodeCount ?? season.episodes?.length ?? 0,
        posterPath: season.posterPath,
        airDate: season.airDate
      })),
      productionCompanies: (metadata.productionCompanies ?? []).map((company) => ({
        id: company.id,
        name: company.name
      })),
      keywords: (metadata.keywords ?? []).map((keyword) => ({ id: keyword.id, name: keyword.name })),
      ratings: (metadata.ratings ?? []).map((rating) => ({
        source: rating.source,
        label: rating.label,
        value: rating.value,
        maxValue: rating.maxValue
      }))
    };
  }
  async toCards(providerId, type, items) {
    const availability = await this.availability.resolve(providerId, type, items.map((item) => ({ externalId: item.externalId, title: item.title, releaseDate: item.releaseDate })));
    return items.map((item) => this.baseCard(providerId, type, item, availability.get(item.externalId)));
  }
  baseCard(providerId, type, item, info) {
    return {
      providerId,
      externalId: item.externalId,
      mediaType: type,
      title: item.title,
      year: releaseYear(item.releaseDate),
      posterPath: item.posterPath,
      backdropPath: item.backdropPath,
      imageUrl: posterImageUrl(item.posterPath),
      overview: item.overview,
      voteAverage: item.voteAverage,
      popularity: item.popularity,
      state: info?.state ?? "none",
      requestId: info?.requestId,
      metadataId: info?.metadataId
    };
  }
  toGenre(id, name) {
    return { id, name };
  }
}

// plugins/media-requests/src/genre-tiles.ts
var CACHE_TTL_MS = 12 * 60 * 60 * 1000;

class GenreTilesService {
  discover;
  cache = new Map;
  constructor(discover) {
    this.discover = discover;
  }
  async list(type, providerId) {
    const key = `${providerId ?? "*"}:${type}`;
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.at < CACHE_TTL_MS)
      return cached.tiles;
    const genres = await this.discover.genres(type, providerId);
    const tiles = await Promise.all(genres.map(async (genre) => {
      const page = await this.discover.discover({ type, category: "popular", page: 1, genreId: genre.id, providerId });
      const backdropPath = page.items.find((item) => item.backdropPath)?.backdropPath;
      return { id: genre.id, name: genre.name, mediaType: type, ...backdropPath ? { backdropPath } : {} };
    }));
    this.cache.set(key, { at: Date.now(), tiles });
    return tiles;
  }
}

// plugins/media-requests/src/provider-access.ts
class ProviderAccess {
  host;
  constructor(host) {
    this.host = host;
  }
  async list() {
    try {
      return await this.host.providers.list();
    } catch (error) {
      this.host.logger.warn("Metadata provider list unavailable", { error });
      return [];
    }
  }
  async discover(query) {
    try {
      return await this.host.providers.discover({
        type: query.type,
        category: query.category,
        page: query.page,
        window: query.window,
        genreId: query.genreId,
        year: query.year,
        providerId: query.providerId
      });
    } catch (error) {
      this.host.logger.warn("Metadata discovery unavailable", { category: query.category, error });
      return null;
    }
  }
  async search(type, query, providerId) {
    try {
      return await this.host.providers.search({ type, query, providerId });
    } catch (error) {
      this.host.logger.warn("Metadata search unavailable", { type, error });
      return [];
    }
  }
  async getDetails(providerId, type, externalId) {
    try {
      return await this.host.providers.getDetails(providerId, type, externalId);
    } catch (error) {
      this.host.logger.warn("Metadata details unavailable", { providerId, externalId, error });
      return null;
    }
  }
  async getSeasonDetails(providerId, externalId, seasonNumber) {
    try {
      return await this.host.providers.getSeasonDetails(providerId, externalId, seasonNumber);
    } catch (error) {
      this.host.logger.warn("Provider season details unavailable", { providerId, externalId, seasonNumber, error });
      return null;
    }
  }
  async getGenres(type, providerId) {
    try {
      return await this.host.providers.getGenres(type, providerId);
    } catch (error) {
      this.host.logger.warn("Metadata genres unavailable", { type, error });
      return [];
    }
  }
}

// plugins/media-requests/src/requests-manager.ts
var STORAGE_KEY_REQUESTS = "requests_list";

class RequestsManager {
  host;
  config;
  constructor(host, config) {
    this.host = host;
    this.config = config;
  }
  async getAllRequests() {
    const stored = await this.host.storage.get(STORAGE_KEY_REQUESTS);
    return isMediaRequestArray(stored) ? stored : [];
  }
  async getRequestById(id) {
    const all = await this.getAllRequests();
    return all.find((r) => r.id === id) ?? null;
  }
  async listRequests(filters) {
    let all = await this.getAllRequests();
    if (filters?.userId) {
      all = all.filter((r) => r.requestedBy.userId === filters.userId);
    }
    if (filters?.statuses) {
      const wanted = new Set(filters.statuses);
      all = all.filter((r) => wanted.has(r.status));
    } else if (filters?.status && filters.status !== "all") {
      all = all.filter((r) => r.status === filters.status);
    }
    if (filters?.mediaType && filters.mediaType !== "all") {
      all = all.filter((r) => r.mediaType === filters.mediaType);
    }
    return all.toSorted((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  async createRequest(input, user) {
    const all = await this.getAllRequests();
    const userActiveCount = all.filter((r) => r.requestedBy.userId === user.userId && (r.status === "pending" || r.status === "approved" || r.status === "in_progress")).length;
    if (userActiveCount >= this.config.maxActiveRequestsPerUser) {
      throw new Error(`Active request limit reached (${this.config.maxActiveRequestsPerUser}). Wait for earlier requests to be fulfilled.`);
    }
    const existing = all.find((r) => input.externalId != null && r.externalId === input.externalId || input.tmdbId != null && r.tmdbId === input.tmdbId || input.imdbId != null && r.imdbId === input.imdbId || r.title.toLowerCase() === input.title.toLowerCase() && r.year === input.year && r.mediaType === input.mediaType);
    if (existing) {
      if (existing.status === "available") {
        throw new Error(`"${input.title}" is already marked as available in the library.`);
      }
      throw new Error(`A request for this title already exists (status: ${existing.status}).`);
    }
    const now = new Date().toISOString();
    const newRequest = {
      id: crypto.randomUUID(),
      title: input.title.trim(),
      mediaType: input.mediaType,
      year: input.year,
      tmdbId: input.tmdbId ?? (input.providerId === "tmdb" ? input.externalId : undefined),
      imdbId: input.imdbId,
      providerId: input.providerId,
      externalId: input.externalId,
      posterPath: input.posterPath,
      overview: input.overview,
      requestedBy: {
        userId: user.userId,
        profileId: user.profileId,
        userName: input.requestedByName ?? user.userName
      },
      status: this.config.autoApprove ? "approved" : "pending",
      notes: input.notes,
      createdAt: now,
      updatedAt: now
    };
    all.push(newRequest);
    await this.host.storage.set(STORAGE_KEY_REQUESTS, all);
    this.host.logger.info("New media request submitted", {
      id: newRequest.id,
      title: newRequest.title,
      status: newRequest.status,
      userId: user.userId
    });
    return newRequest;
  }
  async updateRequestStatus(id, status, notes) {
    const all = await this.getAllRequests();
    const req = all.find((r) => r.id === id);
    if (!req) {
      throw new Error(`Request with ID ${id} not found.`);
    }
    const now = new Date().toISOString();
    req.status = status;
    req.updatedAt = now;
    if (notes !== undefined)
      req.notes = notes === "" ? undefined : notes;
    if (status === "available") {
      req.availableAt = now;
    } else {
      req.availableAt = undefined;
      req.matchedMetadataId = undefined;
    }
    await this.host.storage.set(STORAGE_KEY_REQUESTS, all);
    this.host.logger.info("Media request status updated", {
      id,
      title: req.title,
      newStatus: status
    });
    return req;
  }
  async deleteRequest(id, requesterUserId, isAdmin = false) {
    const all = await this.getAllRequests();
    const index = all.findIndex((r) => r.id === id);
    const req = all[index];
    if (!req) {
      throw new Error(`Request with ID ${id} not found.`);
    }
    if (!isAdmin && requesterUserId && req.requestedBy.userId !== requesterUserId) {
      throw new Error("You do not have permission to delete this request.");
    }
    all.splice(index, 1);
    await this.host.storage.set(STORAGE_KEY_REQUESTS, all);
    this.host.logger.info("Media request deleted", { id, title: req.title });
  }
  async markAsAvailable(request, metadataId) {
    const all = await this.getAllRequests();
    const req = all.find((r) => r.id === request.id);
    if (!req)
      return;
    if (req.status === "available")
      return;
    const now = new Date().toISOString();
    req.status = "available";
    req.availableAt = now;
    req.updatedAt = now;
    req.matchedMetadataId = metadataId;
    await this.host.storage.set(STORAGE_KEY_REQUESTS, all);
    this.host.logger.info("Media request fulfilled and marked as available", {
      requestId: req.id,
      title: req.title,
      metadataId,
      userId: req.requestedBy.userId
    });
    if (this.config.notifyOnAvailable) {
      try {
        await this.host.notifications.create({
          userId: req.requestedBy.userId,
          profileId: req.requestedBy.profileId,
          type: "media.available",
          title: "Your requested title is now available!",
          message: `"${req.title}" was just added to your ReelVault library.`,
          data: {
            requestId: req.id,
            metadataId,
            title: req.title,
            mediaType: req.mediaType
          },
          link: `/metadata/${metadataId}`
        });
        this.host.logger.info("Notification sent to user for fulfilled request", {
          userId: req.requestedBy.userId,
          title: req.title
        });
      } catch (err) {
        this.host.logger.error("Failed to send availability notification", err, {
          userId: req.requestedBy.userId,
          requestId: req.id
        });
      }
    }
  }
  async getSummary() {
    const all = await this.getAllRequests();
    return {
      total: all.length,
      pending: all.filter((r) => r.status === "pending").length,
      approved: all.filter((r) => r.status === "approved").length,
      inProgress: all.filter((r) => r.status === "in_progress").length,
      available: all.filter((r) => r.status === "available").length,
      rejected: all.filter((r) => r.status === "rejected").length
    };
  }
}
function isMediaRequestArray(value) {
  return Array.isArray(value);
}

// plugins/media-requests/index.ts
var DISCOVERY_CATEGORIES = new Set([
  "trending",
  "popular",
  "upcoming",
  "top_rated",
  "now_playing",
  "recommendations",
  "similar"
]);
function parseMediaType(value) {
  return value === "tv_show" ? "tv_show" : "movie";
}
function parsePositiveInt(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : fallback;
}
function parseOptionalPositiveInt(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : undefined;
}
function isDiscoveryCategory(value) {
  return value !== undefined && DISCOVERY_CATEGORIES.has(value);
}
function isRequestStatus(value) {
  return value === "pending" || value === "approved" || value === "in_progress" || value === "available" || value === "rejected";
}
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function nonEmpty(value) {
  return value === undefined || value === "" ? undefined : value;
}
function optionalString(record, key) {
  const value = record[key];
  return typeof value === "string" && value !== "" ? value : undefined;
}
function parseCreateRequestInput(body) {
  if (!isRecord(body))
    return null;
  const title = typeof body.title === "string" ? body.title : "";
  const mediaType = body.mediaType === "movie" || body.mediaType === "tv_show" ? body.mediaType : undefined;
  if (!(title && mediaType))
    return null;
  const year = typeof body.year === "number" && Number.isFinite(body.year) ? Math.floor(body.year) : undefined;
  const providerId = optionalString(body, "providerId");
  const externalId = optionalString(body, "externalId");
  const tmdbId = optionalString(body, "tmdbId");
  const imdbId = optionalString(body, "imdbId");
  const posterPath = optionalString(body, "posterPath");
  const overview = optionalString(body, "overview");
  const notes = optionalString(body, "notes");
  const requestedByName = optionalString(body, "requestedByName");
  return {
    title,
    mediaType,
    ...year !== undefined ? { year } : {},
    ...providerId ? { providerId } : {},
    ...externalId ? { externalId } : {},
    ...tmdbId ? { tmdbId } : {},
    ...imdbId ? { imdbId } : {},
    ...posterPath ? { posterPath } : {},
    ...overview ? { overview } : {},
    ...notes ? { notes } : {},
    ...requestedByName ? { requestedByName } : {}
  };
}
var media_requests_default = definePlugin(config, {
  async setup(host) {
    const manager = new RequestsManager(host, host.config);
    const checker = new AvailabilityChecker(host, manager);
    const providerAccess = new ProviderAccess(host);
    const availability = new AvailabilityService(host, manager);
    const discoverService = new DiscoverService(providerAccess, availability);
    const genreTiles = new GenreTilesService(discoverService);
    const notifyChange = (payload) => {
      try {
        host.realtime.broadcast("requests.changed", payload);
      } catch (error) {
        host.logger.warn("Failed to broadcast requests change", { error });
      }
    };
    host.logger.info("Media Requests plugin initialized", {
      autoApprove: host.config.autoApprove,
      notifyOnAvailable: host.config.notifyOnAvailable,
      maxActiveRequestsPerUser: host.config.maxActiveRequestsPerUser
    });
    await host.tasks.register({
      id: "media-requests-sync",
      name: "media-requests-sync",
      description: "media-requests-sync",
      defaultTriggers: [{ id: "requests-sync-interval", type: "interval", intervalMinutes: 60 }],
      run: async () => {
        const result = await checker.syncAllRequests();
        host.logger.info("Media requests sync completed", result);
        return;
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/providers",
      handler: async () => ({
        body: { providers: await providerAccess.list() }
      })
    });
    await host.routes.register({
      method: "GET",
      path: "/discover",
      handler: async ({ query }) => {
        if (!isDiscoveryCategory(query.category)) {
          return { status: 400, body: { error: "Invalid discovery category." } };
        }
        const result = await discoverService.discover({
          type: parseMediaType(query.mediaType),
          category: query.category,
          page: parsePositiveInt(query.page, 1),
          window: query.window === "day" ? "day" : "week",
          genreId: nonEmpty(query.genreId),
          year: parseOptionalPositiveInt(query.year),
          providerId: nonEmpty(query.providerId)
        });
        return { body: result };
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/search",
      handler: async ({ query }) => {
        const text = (query.query ?? query.q ?? "").trim();
        if (!text)
          return { body: { items: [] } };
        const result = await discoverService.search(parseMediaType(query.mediaType), text);
        return { body: result };
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/genres",
      handler: async ({ query }) => ({
        body: { genres: await discoverService.genres(parseMediaType(query.mediaType), nonEmpty(query.providerId)) }
      })
    });
    await host.routes.register({
      method: "GET",
      path: "/details",
      handler: async ({ query }) => {
        const providerId = query.providerId;
        const externalId = query.externalId;
        if (!(providerId && externalId)) {
          return { status: 400, body: { error: "The 'providerId' and 'externalId' fields are required." } };
        }
        const details = await discoverService.details(providerId, parseMediaType(query.mediaType), externalId);
        if (!details)
          return { status: 404, body: { error: "Title details not found." } };
        return { body: details };
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/seasons",
      handler: async ({ query }) => {
        const providerId = query.providerId;
        const externalId = query.externalId;
        if (!(providerId && externalId)) {
          return { status: 400, body: { error: "The 'providerId' and 'externalId' fields are required." } };
        }
        const season = await discoverService.seasonDetails(providerId, externalId, parsePositiveInt(query.seasonNumber, 1));
        if (!season)
          return { status: 404, body: { error: "Season not found." } };
        return { body: season };
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/genre-tiles",
      handler: async ({ query }) => ({
        body: { tiles: await genreTiles.list(parseMediaType(query.mediaType), nonEmpty(query.providerId)) }
      })
    });
    await host.routes.register({
      method: "GET",
      path: "/requests",
      handler: async ({ query, user }) => {
        const status = isRequestStatus(query.status) ? query.status : undefined;
        const mediaType = query.mediaType === "movie" || query.mediaType === "tv_show" ? query.mediaType : undefined;
        const scope = query.scope === "all" ? "all" : "me";
        const isUserScope = scope === "me" || user.role !== "admin";
        const userId = isUserScope ? user.id : undefined;
        const requests = await manager.listRequests({
          userId,
          status,
          mediaType
        });
        return {
          body: {
            requests,
            total: requests.length
          }
        };
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/requests/summary",
      handler: async () => {
        const summary = await manager.getSummary();
        return {
          body: summary
        };
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/coming-soon",
      handler: async () => {
        if (!host.config.showDashboardSection) {
          return { body: { enabled: false, items: [] } };
        }
        const items = (await manager.listRequests({ statuses: ["approved", "in_progress"] })).toSorted((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()).slice(0, 20);
        return { body: { enabled: true, items } };
      }
    });
    await host.routes.register({
      method: "POST",
      path: "/requests",
      handler: async ({ body, user }) => {
        const input = parseCreateRequestInput(body);
        if (!input) {
          return {
            body: { error: "The 'title' and 'mediaType' ('movie' | 'tv_show') fields are required." }
          };
        }
        try {
          const request = await manager.createRequest(input, {
            userId: user.id,
            profileId: user.profileId
          });
          notifyChange({ action: "created", requestId: request.id });
          return {
            status: 201,
            body: {
              success: true,
              request
            }
          };
        } catch (err) {
          return {
            body: { error: err instanceof Error ? err.message : "Failed to create the request." }
          };
        }
      }
    });
    await host.routes.register({
      method: "PATCH",
      path: "/requests/:id",
      access: "admin",
      handler: async ({ params, body }) => {
        const id = params.id;
        if (!id) {
          return { body: { error: "Missing request ID." } };
        }
        if (!(isRecord(body) && isRequestStatus(body.status))) {
          return { body: { error: "Invalid request status." } };
        }
        const notes = typeof body.notes === "string" ? body.notes : undefined;
        try {
          const updated = await manager.updateRequestStatus(id, body.status, notes);
          notifyChange({ action: "updated", requestId: id });
          return {
            body: {
              success: true,
              request: updated
            }
          };
        } catch (err) {
          return {
            body: { error: err instanceof Error ? err.message : "Failed to update the request." }
          };
        }
      }
    });
    await host.routes.register({
      method: "DELETE",
      path: "/requests/:id",
      handler: async ({ params, user }) => {
        const id = params.id;
        if (!id) {
          return { body: { error: "Missing request ID." } };
        }
        const isAdmin = user.role === "admin";
        const userId = user.id;
        try {
          await manager.deleteRequest(id, userId, isAdmin);
          notifyChange({ action: "deleted", requestId: id });
          return {
            body: {
              success: true,
              message: "The request was deleted."
            }
          };
        } catch (err) {
          return {
            body: { error: err instanceof Error ? err.message : "Failed to delete the request." }
          };
        }
      }
    });
    host.events.on("media.file.ready", async (event) => {
      host.logger.debug("Received media.file.ready event, checking requests match", {
        metadataId: event.metadataId
      });
      try {
        const fulfilled = await checker.checkMetadata(event.metadataId);
        if (fulfilled > 0) {
          host.logger.info(`Fulfilled ${fulfilled} media requests via media.file.ready event`, {
            metadataId: event.metadataId
          });
          notifyChange({ action: "available", metadataId: event.metadataId });
        }
      } catch (err) {
        host.logger.error("Error checking media requests on media.file.ready event", err);
      }
    });
  }
});
export {
  media_requests_default as default
};
