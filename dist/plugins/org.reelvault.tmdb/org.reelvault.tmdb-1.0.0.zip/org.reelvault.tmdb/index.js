// @bun
// plugins/tmdb/index.ts
import { definePlugin } from "@reelvault/sdk/plugin";

// plugins/tmdb/config.ts
import { defineConfig, field } from "@reelvault/sdk/plugin";
var LANGUAGE_TAG = /^[a-z]{2,3}(?:-[A-Z]{2})?$/;
var config = defineConfig({
  apiKey: field.secret({
    label: "TMDB API key (Read Access Token)",
    description: "API key or v4 token from themoviedb.org, used to fetch metadata and artwork.",
    required: true,
    default: ""
  }),
  language: field.string({
    label: "Metadata language",
    description: "ISO language code (e.g. en-US, pl-PL) used to fetch overviews, titles and details.",
    default: "en-US",
    pattern: LANGUAGE_TAG
  }),
  fallbackLanguage: field.string({
    label: "Fallback language",
    description: "Fallback ISO language code (e.g. en-US) used when translated overviews or titles are missing.",
    default: "en-US",
    pattern: LANGUAGE_TAG
  }),
  searchLanguage: field.string({
    label: "Search language",
    description: "ISO language code (e.g. en-US or pl-PL) used when searching TMDB \u2014 often en-US for English release names.",
    default: "en-US",
    pattern: LANGUAGE_TAG
  })
});

// plugins/tmdb/node_modules/@lorenzopant/tmdb/dist/images.mjs
var e = `http://image.tmdb.org/t/p/`;
var t = `https://image.tmdb.org/t/p/`;
function s(e) {
  return typeof e == `object` && !!e && !Array.isArray(e);
}
function c(e) {
  if (!s(e))
    return false;
  let t = Object.getPrototypeOf(e);
  return t === Object.prototype || t === null;
}
var m = { backdrop_path: `backdrop`, logo_path: `logo`, poster_path: `poster`, profile_path: `profile`, still_path: `still` };
var h = { backdrop_path: `backdrops`, logo_path: `logos`, poster_path: `posters`, profile_path: `profiles`, still_path: `stills` };
var g = { backdrops: `backdrop_path`, logos: `logo_path`, posters: `poster_path`, profiles: `profile_path`, stills: `still_path` };
var _ = class {
  options;
  constructor(e = {}) {
    this.options = { secure_images_url: true, ...e };
  }
  buildUrl(n, r) {
    return `${this.options.secure_images_url ? t : e}${r}${n}`;
  }
  backdrop(e, t = this.options.default_image_sizes?.backdrops || `w780`) {
    return this.buildUrl(e, t);
  }
  logo(e, t = this.options.default_image_sizes?.logos || `w185`) {
    return this.buildUrl(e, t);
  }
  poster(e, t = this.options.default_image_sizes?.posters || `w500`) {
    return this.buildUrl(e, t);
  }
  profile(e, t = this.options.default_image_sizes?.profiles || `w185`) {
    return this.buildUrl(e, t);
  }
  still(e, t = this.options.default_image_sizes?.still || `w300`) {
    return this.buildUrl(e, t);
  }
  autocompleteImagePaths(e, t) {
    return this.traverse(e, t, true);
  }
  applyFallbacksOnly(e) {
    return this.traverse(e, undefined, false);
  }
  traverse(e, t, n) {
    if (Array.isArray(e)) {
      let r = n && t && this.options.image_language_priority?.[t];
      return (r ? this.sortByLanguagePriority(e, r) : e).map((e) => this.traverse(e, t, n));
    }
    if (!c(e))
      return e;
    let r = Object.create(null);
    for (let [i, a] of Object.entries(e)) {
      if (i === `__proto__` || i === `constructor` || i === `prototype`) {
        r[i] = a;
        continue;
      }
      if (a == null) {
        if (Object.hasOwn(m, i)) {
          let e = h[i];
          r[i] = this.getFallbackForCollection(e) ?? a;
          continue;
        }
        if (i === `file_path` && t) {
          r[i] = this.getFallbackForCollection(t) ?? a;
          continue;
        }
        r[i] = a;
        continue;
      }
      if (typeof a == `string`) {
        r[i] = n ? this.transformPathValue(i, a, t) : a;
        continue;
      }
      let e = this.isImageCollectionKey(i) ? i : t;
      r[i] = this.traverse(a, e, n);
    }
    return r;
  }
  sortByLanguagePriority(e, t) {
    let n = [], r = [...e];
    for (let e of t) {
      if (e === `*`) {
        n.push(...r.splice(0, r.length));
        break;
      }
      let t = [];
      for (let i of r) {
        let r = i?.iso_639_1;
        (e === `null` ? r == null : r === e) ? n.push(i) : t.push(i);
      }
      r.length = 0, r.push(...t);
    }
    return n.push(...r), n;
  }
  isImageCollectionKey(e) {
    return Object.hasOwn(g, e);
  }
  getFallbackForCollection(e) {
    let t = this.options.fallback_url;
    if (t != null)
      return typeof t == `string` ? t : t[e];
  }
  isFullUrl(e) {
    return /^https?:\/\//.test(e);
  }
  buildImageUrl(e, t) {
    let n = m[e];
    return Object.hasOwn(this, n) || this[n], this[n](t);
  }
  transformPathValue(e, t, n) {
    return !t.startsWith(`/`) || this.isFullUrl(t) ? t : Object.hasOwn(m, e) ? this.buildImageUrl(e, t) : e === `file_path` && n ? this.buildImageUrl(g[n], t) : t;
  }
};

// plugins/tmdb/node_modules/@lorenzopant/tmdb/dist/tmdb.mjs
var t2 = class extends Error {
  tmdb_status_code;
  message;
  http_status_code;
  constructor(e, t, n) {
    super(e), this.name = `TMDBError`, this.tmdb_status_code = n || -1, this.message = e, this.http_status_code = t;
  }
};
var n = class e {
  logger;
  constructor(e) {
    this.logger = e;
  }
  static from(t) {
    if (t)
      return t === true ? new e(e.defaultLogger) : new e(t);
  }
  log(e) {
    if (this.logger)
      try {
        this.logger(e);
      } catch (e) {
        console.warn(`TMDB logger error: ${String(e)}`);
      }
  }
  static defaultLogger = (e) => {
    let t = `\uD83C\uDFAC [tmdb]`, n = new Date().toISOString();
    if (e.type === `request`) {
      console.log(`${t} ${n} \uD83D\uDEF0\uFE0F REQUEST ${e.method} ${e.endpoint} 
`);
      return;
    }
    if (e.type === `response`) {
      console.log(`${t} ${n} \u2705 RESPONSE ${e.method} ${e.status} ${e.statusText} ${e.endpoint} (${e.durationMs}ms)
`);
      return;
    }
    let r = e.status == null ? `NETWORK ERROR` : `${e.status} ${e.statusText}`, i = e.tmdbStatusCode == null ? `` : ` (tmdb: ${e.tmdbStatusCode})`;
    console.log(`${t} ${n} \u274C ${e.method} ${r} ${e.endpoint} - ${e.errorMessage}${i}
`);
  };
};
function r(e) {
  return /^[A-Za-z0-9\-_]+$/.test(e);
}
function i(e) {
  try {
    let t = e.replace(/-/g, `+`).replace(/_/g, `/`), n = t.padEnd(t.length + (4 - t.length % 4) % 4, `=`);
    return atob(n);
  } catch {
    return null;
  }
}
function a(e) {
  return typeof e == `object` && !!e;
}
function o(e) {
  return a(e) ? typeof e.alg == `string` : false;
}
function s2(e) {
  return !(!a(e) || (`exp` in e) && typeof e.exp != `number` || (`nbf` in e) && typeof e.nbf != `number` || (`iat` in e) && typeof e.iat != `number`);
}
function c2(e) {
  if (typeof e != `string`)
    return false;
  let t = e.split(`.`);
  if (t.length !== 3)
    return false;
  let [n, a, c] = t;
  if (!r(n) || !r(a) || !r(c))
    return false;
  let l = i(n), u = i(a);
  if (!l || !u)
    return false;
  let d, f;
  try {
    d = JSON.parse(l), f = JSON.parse(u);
  } catch {
    return false;
  }
  return !(!o(d) || !s2(f));
}
var l = { NO_ACCESS_TOKEN: `TMDB requires a valid access token, please provide one.`, INVALID_CLIENT: `TMDB received an invalid ApiClient instance. Pass a valid ApiClient or an access token string.`, V4_REQUIRES_JWT: `TMDB v4 requires a Bearer (JWT) access token. API key strings are not supported for v4 endpoints.`, INVALID_START_PAGE: `Invalid page: Pages start at 1 and max at 500. They are expected to be an integer.` };
var ae = class {
  ttl;
  maxSize;
  excludedEndpoints;
  store = new Map;
  constructor(e = {}) {
    let t = e.ttl ?? 300000;
    if (!Number.isFinite(t) || !Number.isInteger(t) || t < 1)
      throw RangeError(`cache.ttl must be a finite integer >= 1 (got ${t})`);
    if (e.max_size !== undefined && (!Number.isFinite(e.max_size) || !Number.isInteger(e.max_size) || e.max_size < 1))
      throw RangeError(`cache.max_size must be a finite integer >= 1 (got ${e.max_size})`);
    this.ttl = t, this.maxSize = e.max_size, this.excludedEndpoints = (e.excluded_endpoints ?? []).map((e) => typeof e != `string` && /[gy]/.test(e.flags) ? new RegExp(e.source, e.flags.replace(/[gy]/g, ``)) : e);
  }
  shouldCache(e) {
    return !this.excludedEndpoints.some((t) => typeof t == `string` ? e.startsWith(t) : t.test(e));
  }
  get(e) {
    let t = this.store.get(e);
    if (t) {
      if (Date.now() > t.expiresAt) {
        this.store.delete(e);
        return;
      }
      return t.value;
    }
  }
  has(e) {
    let t = this.store.get(e);
    return t ? Date.now() > t.expiresAt ? (this.store.delete(e), false) : true : false;
  }
  set(e, t) {
    this.maxSize !== undefined && !this.store.has(e) && this.store.size >= this.maxSize && this.store.delete(this.store.keys().next().value), this.store.set(e, { value: t, expiresAt: Date.now() + this.ttl });
  }
  delete(e) {
    return this.store.delete(e);
  }
  clear() {
    this.store.clear();
  }
  get size() {
    return this.store.size;
  }
};
var oe = class {
  maxRequests;
  windowMs;
  timestamps = [];
  queue = [];
  processing = false;
  constructor(e = {}) {
    let t = e.max_requests ?? 40, n = e.per_ms ?? 1000;
    if (!Number.isFinite(t) || !Number.isInteger(t) || t < 1)
      throw RangeError(`rate_limit.max_requests must be a finite integer >= 1 (got ${t})`);
    if (!Number.isFinite(n) || !Number.isInteger(n) || n < 1)
      throw RangeError(`rate_limit.per_ms must be a finite integer >= 1 (got ${n})`);
    this.maxRequests = t, this.windowMs = n;
  }
  acquire() {
    return new Promise((e) => {
      this.queue.push(e), this.processing || this.process();
    });
  }
  async process() {
    for (this.processing = true;this.queue.length > 0; ) {
      let e = Date.now();
      if (this.timestamps = this.timestamps.filter((t) => e - t < this.windowMs), this.timestamps.length < this.maxRequests)
        this.timestamps.push(Date.now()), this.queue.shift()();
      else {
        let e = this.timestamps[0], t = this.windowMs - (Date.now() - e) + 1;
        await new Promise((e) => setTimeout(e, t));
      }
    }
    this.processing = false;
  }
};
function se(e) {
  if (e instanceof t2)
    return e.http_status_code >= 500;
  if (e instanceof Error)
    switch (e.name) {
      case `FetchError`:
      case `AbortError`:
        return true;
      case `SyntaxError`:
        return false;
      case `TypeError`:
        return true;
      default:
        return false;
    }
  return true;
}
var ce = class {
  maxRetries;
  baseDelayMs;
  maxDelayMs;
  shouldRetry;
  constructor(e = {}) {
    let t = e.max_retries ?? 3, n = e.base_delay_ms ?? 500, r = e.max_delay_ms ?? 30000;
    if (!Number.isFinite(t) || !Number.isInteger(t) || t < 0)
      throw RangeError(`retry.max_retries must be a finite integer >= 0 (got ${t})`);
    if (!Number.isFinite(n) || !Number.isInteger(n) || n < 1)
      throw RangeError(`retry.base_delay_ms must be a finite integer >= 1 (got ${n})`);
    if (!Number.isFinite(r) || !Number.isInteger(r) || r < 1)
      throw RangeError(`retry.max_delay_ms must be a finite integer >= 1 (got ${r})`);
    this.maxRetries = t, this.baseDelayMs = n, this.maxDelayMs = r, this.shouldRetry = e.shouldRetry ?? se;
  }
  delayFor(e) {
    let t = Math.min(this.baseDelayMs * 2 ** (e - 1), this.maxDelayMs);
    return Math.floor(Math.random() * t);
  }
  async execute(e, t = le) {
    let n;
    for (let r = 0;r <= this.maxRetries; r++)
      try {
        return await e();
      } catch (e) {
        if (n = e, r >= this.maxRetries || !await this.shouldRetry(e, r + 1))
          break;
        let i = this.delayFor(r + 1);
        i > 0 && await t(i);
      }
    throw n;
  }
};
function le(e) {
  return new Promise((t) => setTimeout(t, e));
}
var b = class {
  accessToken;
  baseUrl;
  logger;
  inflightRequests = new Map;
  deduplication;
  rateLimiter;
  retryManager;
  requestInterceptors;
  onSuccessInterceptor;
  onErrorInterceptor;
  imageApi;
  imageOptions;
  responseCache;
  constructor(t, r = {}) {
    if (this.accessToken = t, this.baseUrl = `https://api.themoviedb.org/${r.version ?? 3}`, this.logger = n.from(r.logger), this.deduplication = r.deduplication !== false, r.rate_limit) {
      let e = r.rate_limit === true ? {} : r.rate_limit;
      this.rateLimiter = new oe(e);
    }
    if (r.retry) {
      let e = r.retry === true ? {} : r.retry;
      this.retryManager = new ce(e);
    }
    if (r.cache) {
      let e = r.cache === true ? {} : r.cache;
      this.responseCache = new ae(e);
    }
    let i = r.interceptors?.request;
    this.requestInterceptors = i == null ? [] : Array.isArray(i) ? i : [i], this.onSuccessInterceptor = r.interceptors?.response?.onSuccess, this.onErrorInterceptor = r.interceptors?.response?.onError, this.imageApi = r.images?.autocomplete_paths || r.images?.fallback_url != null ? new _(r.images) : undefined, this.imageOptions = r.images;
  }
  buildRequestKey(e, t) {
    let n = this.serializeParams(t).sort(([e], [t]) => e.localeCompare(t)).map(([e, t]) => `${e}=${t}`);
    return n.length > 0 ? `${e}?${n.join(`&`)}` : e;
  }
  serializeParams(e) {
    return Object.entries(e).flatMap(([e, t]) => t === undefined ? [] : [[e, String(t)]]);
  }
  async request(e, t = {}) {
    let n = await this.runRequestInterceptors({ endpoint: e, params: t, method: `GET` }), { endpoint: r, params: i } = n, a = this.buildRequestKey(r, i), o = !!this.responseCache?.shouldCache(a);
    if (o && this.responseCache.has(a))
      return this.responseCache.get(a);
    if (!this.deduplication) {
      let e = await this.execute(`GET`, r, i, undefined, true);
      return o && this.responseCache.set(a, e), e;
    }
    let s = this.inflightRequests.get(a);
    if (s)
      return s;
    let c = o ? this.responseCache : undefined, l = this.execute(`GET`, r, i, undefined, true).then((e) => (c?.set(a, e), e)).finally(() => {
      this.inflightRequests.delete(a);
    });
    return this.inflightRequests.set(a, l), l;
  }
  invalidateCache(e, t = {}) {
    return this.responseCache ? this.responseCache.delete(this.buildRequestKey(e, t)) : false;
  }
  clearCache() {
    this.responseCache?.clear();
  }
  get cacheSize() {
    return this.responseCache?.size ?? 0;
  }
  async runRequestInterceptors(e) {
    let t = e;
    for (let e of this.requestInterceptors) {
      let n = await e(t);
      n != null && (t = n);
    }
    return t;
  }
  sanitizeNulls(e) {
    if (e === null)
      return;
    if (typeof e != `object`)
      return e;
    if (Array.isArray(e))
      return e.map((e) => this.sanitizeNulls(e));
    let t = {};
    for (let [n, r] of Object.entries(e))
      t[n] = this.sanitizeNulls(r);
    return t;
  }
  async normalizeError(e, n, r) {
    let i = e.statusText, a = -1;
    try {
      let t = await e.json();
      if (t && typeof t == `object`) {
        let e = t;
        i = e.status_message || i, a = e.status_code || -1;
      }
    } catch (e) {
      console.error(`Unknown error: ${String(e)}`);
    }
    return this.logger?.log({ type: `error`, method: r, endpoint: n, status: e.status, statusText: e.statusText, tmdbStatusCode: a, errorMessage: i }), new t2(i, e.status, a);
  }
  async notifyErrorInterceptor(e) {
    this.onErrorInterceptor && await this.onErrorInterceptor(e);
  }
  async mutate(e, t, n, r = {}) {
    return this.execute(e, t, r, n);
  }
  async execute(e, n, r, i, a = false) {
    let o = i === undefined ? undefined : JSON.stringify(i), s, l;
    if (a)
      s = n, l = r;
    else {
      let t = await this.runRequestInterceptors({ endpoint: n, params: r, method: e });
      s = t.endpoint, l = t.params;
    }
    let u = new URL(`${this.baseUrl}${s}`), d = c2(this.accessToken);
    for (let [e, t] of this.serializeParams(l))
      u.searchParams.append(e, t);
    d || u.searchParams.append(`api_key`, this.accessToken);
    let f = Date.now();
    this.logger?.log({ type: `request`, method: e, endpoint: s });
    let p = async () => {
      this.rateLimiter && await this.rateLimiter.acquire();
      let t;
      try {
        t = await fetch(u.toString(), { method: e, headers: d ? { Authorization: `Bearer ${this.accessToken}`, "Content-Type": `application/json;charset=utf-8` } : { "Content-Type": `application/json;charset=utf-8` }, ...o === undefined ? {} : { body: o } });
      } catch (t) {
        throw this.logger?.log({ type: `error`, method: e, endpoint: s, errorMessage: t instanceof Error ? t.message : String(t), durationMs: Date.now() - f }), t;
      }
      if (!t.ok)
        throw await this.normalizeError(t, s, e);
      return t;
    }, m;
    try {
      m = this.retryManager ? await this.retryManager.execute(p) : await p();
    } catch (e) {
      throw e instanceof t2 && await this.notifyErrorInterceptor(e), e;
    }
    this.logger?.log({ type: `response`, method: e, endpoint: s, status: m.status, statusText: m.statusText, durationMs: Date.now() - f });
    let h = await m.json(), g = this.sanitizeNulls(h), _ = this.imageApi ? this.imageOptions?.autocomplete_paths ? this.imageApi.autocompleteImagePaths(g) : this.imageApi.applyFallbacksOnly(g) : g;
    if (this.onSuccessInterceptor) {
      let e = await this.onSuccessInterceptor(_);
      return e === undefined ? _ : e;
    }
    return _;
  }
};
var x = { AUTHENTICATION: { VALIDATE: `/authentication`, GUEST_SESSION: `/authentication/guest_session/new`, REQUEST_TOKEN: `/authentication/token/new`, CREATE_SESSION: `/authentication/session/new`, CREATE_SESSION_WITH_LOGIN: `/authentication/token/validate_with_login`, DELETE_SESSION: `/authentication/session` }, ACCOUNT: { DETAILS: `/account`, ADD_FAVORITE: `/favorite`, ADD_TO_WATCHLIST: `/watchlist`, FAVORITE_MOVIES: `/favorite/movies`, FAVORITE_TV: `/favorite/tv`, WATCHLIST_MOVIES: `/watchlist/movies`, WATCHLIST_TV: `/watchlist/tv`, RATED_MOVIES: `/rated/movies`, RATED_TV: `/rated/tv`, RATED_TV_EPISODES: `/rated/tv/episodes`, LISTS: `/lists` }, CONFIGURATION: { DETAILS: `/configuration`, COUNTRIES: `/configuration/countries`, JOBS: `/configuration/jobs`, LANGUAGES: `/configuration/languages`, TIMEZONES: `/configuration/timezones`, PRIMARY_TRANSLATIONS: `/configuration/primary_translations` }, CERTIFICATIONS: { MOVIE_CERTIFICATIONS: `/certification/movie/list`, TV_CERTIFICATIONS: `/certification/tv/list` }, CHANGES: { MOVIE_LIST: `/movie/changes`, PEOPLE_LIST: `/person/changes`, TV_LIST: `/tv/changes` }, DISCOVER: { MOVIE: `/discover/movie`, TV: `/discover/tv` }, FIND: `/find`, CREDITS: { DETAILS: `/credit` }, COMPANIES: { DETAILS: `/company`, ALTERNATIVE_NAMES: `/alternative_names`, IMAGES: `/images` }, COLLECTIONS: { DETAILS: `/collection`, IMAGES: `/images`, TRANSLATIONS: `/translations` }, GENRES: { MOVIE_LIST: `/genre/movie/list`, TV_LIST: `/genre/tv/list` }, KEYWORDS: { DETAILS: `/keyword`, MOVIES: `/movies` }, MOVIES: { DETAILS: `/movie`, ALTERNATIVE_TITLES: `/alternative_titles`, CREDITS: `/credits`, EXTERNAL_IDS: `/external_ids`, KEYWORDS: `/keywords`, CHANGES: `/changes`, IMAGES: `/images`, LATEST: `/latest`, NOW_PLAYING: `/now_playing`, POPULAR: `/popular`, RECOMMENDATIONS: `/recommendations`, RELEASE_DATES: `/release_dates`, REVIEWS: `/reviews`, SIMILAR: `/similar`, TOP_RATED: `/top_rated`, TRANSLATIONS: `/translations`, UPCOMING: `/upcoming`, VIDEOS: `/videos`, WATCH_PROVIDERS: `/watch/providers` }, NETWORKS: { DETAILS: `/network`, ALTERNATIVE_NAMES: `/alternative_names`, IMAGES: `/images` }, PEOPLE: { DETAILS: `/person`, CHANGES: `/changes`, COMBINED_CREDITS: `/combined_credits`, EXTERNAL_IDS: `/external_ids`, IMAGES: `/images`, LATEST: `/latest`, MOVIE_CREDITS: `/movie_credits`, TAGGED_IMAGES: `/tagged_images`, TRANSLATIONS: `/translations`, TV_CREDITS: `/tv_credits` }, SEARCH: { MOVIE: `/search/movie`, COLLECTION: `/search/collection`, COMPANY: `/search/company`, KEYWORD: `/search/keyword`, MULTI: `/search/multi`, PERSON: `/search/person`, TV: `/search/tv` }, TV_SERIES: { DETAILS: `/tv`, AGGREGATE_CREDITS: `/aggregate_credits`, AIRING_TODAY: `/airing_today`, ALTERNATIVE_TITLES: `/alternative_titles`, CHANGES: `/changes`, CONTENT_RATINGS: `/content_ratings`, CREDITS: `/credits`, EPISODE_GROUPS: `/episode_groups`, EXTERNAL_IDS: `/external_ids`, IMAGES: `/images`, KEYWORDS: `/keywords`, LATEST: `/latest`, LISTS: `/lists`, ON_THE_AIR: `/on_the_air`, POPULAR: `/popular`, RECOMMENDATIONS: `/recommendations`, REVIEWS: `/reviews`, SCREENED_THEATRICALLY: `/screened_theatrically`, SIMILAR: `/similar`, TOP_RATED: `/top_rated`, TRANSLATIONS: `/translations`, VIDEOS: `/videos`, WATCH_PROVIDERS: `/watch/providers` }, TV_SEASONS: { DETAILS: `/season`, AGGREGATE_CREDITS: `/aggregate_credits`, CHANGES: `/changes`, CREDITS: `/credits`, EXTERNAL_IDS: `/external_ids`, IMAGES: `/images`, TRANSLATIONS: `/translations`, VIDEOS: `/videos`, WATCH_PROVIDERS: `/watch/providers` }, TV_EPISODES: { DETAILS: `/episode`, CHANGES: `/changes`, CREDITS: `/credits`, EXTERNAL_IDS: `/external_ids`, IMAGES: `/images`, TRANSLATIONS: `/translations`, VIDEOS: `/videos` }, TV_EPISODE_GROUPS: { DETAILS: `/tv/episode_group` }, WATCH_PROVIDERS: { MOVIE: `/watch/providers/movie`, TV: `/watch/providers/tv`, REGIONS: `/watch/providers/regions` }, TRENDING: { ALL: `/trending/all`, MOVIE: `/trending/movie`, TV: `/trending/tv`, PERSON: `/trending/person` }, REVIEWS: { DETAILS: `/review` }, PEOPLE_LISTS: { POPULAR: `/person/popular` }, LISTS: { DETAILS: `/list`, ADD_ITEM: `/add_item`, ITEM_STATUS: `/item_status`, CLEAR: `/clear`, REMOVE_ITEM: `/remove_item` }, GUEST_SESSIONS: { DETAILS: `/guest_session`, RATED_MOVIES: `/rated/movies`, RATED_TV: `/rated/tv`, RATED_TV_EPISODES: `/rated/tv/episodes` } };
var S = { AUTH: { REQUEST_TOKEN: `/auth/request_token`, ACCESS_TOKEN: `/auth/access_token` }, ACCOUNT: { DETAILS: `/account`, LISTS: `/lists`, FAVORITE_MOVIES: `/favorite/movies`, FAVORITE_TV: `/favorite/tv`, WATCHLIST_MOVIES: `/watchlist/movies`, WATCHLIST_TV: `/watchlist/tv`, RATED_MOVIES: `/rated/movies`, RATED_TV: `/rated/tv` }, LISTS: { DETAILS: `/list`, ITEMS: `/items`, ITEM_STATUS: `/item_status`, CLEAR: `/clear` } };
var C = class {
  client;
  defaultOptions;
  constructor(e, t = {}) {
    if (typeof e == `string`) {
      if (!e)
        throw Error(l.NO_ACCESS_TOKEN);
      this.client = new b(e, { logger: t.logger, deduplication: t.deduplication, rate_limit: t.rate_limit, interceptors: t.interceptors });
    } else if (e instanceof b)
      this.client = e;
    else
      throw Error(e == null ? l.NO_ACCESS_TOKEN : l.INVALID_CLIENT);
    this.defaultOptions = t;
  }
  applyDefaults(e) {
    let { language: t, region: n } = this.defaultOptions;
    return { ...t !== undefined && { language: t }, ...n !== undefined && { region: n }, ...e };
  }
  withLanguage(e) {
    let t = this.defaultOptions?.language;
    return e ? e.language !== undefined || t === undefined ? e : { ...e, language: t } : t === undefined ? undefined : { language: t };
  }
  injectImageLanguage(e) {
    if (!this.defaultOptions.images?.auto_include_image_language || e.include_image_language !== undefined)
      return e;
    let t = this.defaultOptions.images?.image_language_priority;
    if (!t)
      return e;
    let n = [...new Set(Object.values(t).flat().filter((e) => e !== `*`))];
    return n.length ? { ...e, include_image_language: n } : e;
  }
  injectImageLanguageForAppends(e) {
    let t = e.append_to_response;
    return (Array.isArray(t) ? t : t === undefined ? [] : [t]).flatMap((e) => typeof e == `string` ? e.split(`,`).map((e) => e.trim()) : []).includes(`images`) ? this.injectImageLanguage(e) : e;
  }
};
var w = class extends C {
  async movie_certifications() {
    return this.client.request(x.CERTIFICATIONS.MOVIE_CERTIFICATIONS);
  }
  async tv_certifications() {
    return this.client.request(x.CERTIFICATIONS.TV_CERTIFICATIONS);
  }
};
var T = class extends C {
  async movie_list(e) {
    return this.client.request(x.CHANGES.MOVIE_LIST, e);
  }
  async people_list(e) {
    return this.client.request(x.CHANGES.PEOPLE_LIST, e);
  }
  async tv_list(e) {
    return this.client.request(x.CHANGES.TV_LIST, e);
  }
};
var E = class extends C {
  companyPath(e) {
    return `${x.COMPANIES.DETAILS}/${e}`;
  }
  async details(e) {
    let t = this.companyPath(e.company_id);
    return this.client.request(t);
  }
  async alternative_names(e) {
    let t = `${this.companyPath(e.company_id)}${x.COMPANIES.ALTERNATIVE_NAMES}`;
    return this.client.request(t);
  }
  async images(e) {
    let { company_id: t, ...n } = e, r = `${this.companyPath(t)}${x.COMPANIES.IMAGES}`;
    return this.client.request(r, this.injectImageLanguage(this.withLanguage(n) ?? n));
  }
};
var D = class extends C {
  creditPath(e) {
    return `${x.CREDITS.DETAILS}/${e}`;
  }
  async details(e) {
    let { credit_id: t, ...n } = e, r = this.creditPath(t);
    return this.client.request(r, this.withLanguage(n));
  }
};
var O = class extends C {
  collectionPath(e) {
    return `${x.COLLECTIONS.DETAILS}/${e}`;
  }
  async details(e) {
    let { language: t = this.defaultOptions.language, collection_id: n } = e, r = this.collectionPath(n);
    return this.client.request(r, { language: t });
  }
  async images(e) {
    let { collection_id: t, ...n } = e, r = `${this.collectionPath(t)}${x.COLLECTIONS.IMAGES}`;
    return this.client.request(r, this.injectImageLanguage(this.withLanguage(n) ?? n));
  }
  async translations(e) {
    let t = `${this.collectionPath(e.collection_id)}${x.COLLECTIONS.TRANSLATIONS}`;
    return this.client.request(t);
  }
};
var k = class extends C {
  async details() {
    return this.client.request(x.CONFIGURATION.DETAILS);
  }
  async countries(e) {
    return this.client.request(x.CONFIGURATION.COUNTRIES, this.withLanguage(e));
  }
  async jobs() {
    return this.client.request(x.CONFIGURATION.JOBS);
  }
  async languages() {
    return this.client.request(x.CONFIGURATION.LANGUAGES);
  }
  async primary_translations() {
    return this.client.request(x.CONFIGURATION.PRIMARY_TRANSLATIONS);
  }
  async timezones() {
    return this.client.request(x.CONFIGURATION.TIMEZONES);
  }
};
var A = class extends C {
  withMovieDefaults(e) {
    if (!e && !this.defaultOptions.language && !this.defaultOptions.region)
      return;
    let t = e?.language ?? this.defaultOptions.language, n = e?.region ?? this.defaultOptions.region;
    return { ...e, language: t, region: n };
  }
  withTVDefaults(e) {
    if (!e && !this.defaultOptions.language && !this.defaultOptions.timezone)
      return;
    let t = e?.language ?? this.defaultOptions.language, n = e?.timezone ?? this.defaultOptions.timezone;
    return { ...e, language: t, timezone: n };
  }
  async movie(e = {}) {
    return this.client.request(x.DISCOVER.MOVIE, this.withMovieDefaults(e));
  }
  async tv(e = {}) {
    return this.client.request(x.DISCOVER.TV, this.withTVDefaults(e));
  }
};
var j = class extends C {
  async by_id(e) {
    let { external_id: t, ...n } = e, r = `${x.FIND}/${encodeURIComponent(t)}`, i = this.withLanguage(n);
    return this.client.request(r, i);
  }
};
var M = class extends C {
  async movie_list(e) {
    return this.client.request(x.GENRES.MOVIE_LIST, this.withLanguage(e));
  }
  async tv_list(e) {
    return this.client.request(x.GENRES.TV_LIST, this.withLanguage(e));
  }
};
var ue = class extends C {
  keywordPath(e) {
    return `${x.KEYWORDS.DETAILS}/${e}`;
  }
  async details(e) {
    let t = this.keywordPath(e.keyword_id);
    return this.client.request(t);
  }
  async movies(e) {
    let { keyword_id: t, ...n } = e, r = `${this.keywordPath(t)}${x.KEYWORDS.MOVIES}`, i = this.withLanguage(n);
    return this.client.request(r, i);
  }
};
var N = class extends C {
  withDefaults(e) {
    let { language: t = this.defaultOptions.language, region: n = this.defaultOptions.region, ...r } = e;
    return { language: t, region: n, ...r };
  }
  fetch_movie_list(e, t = {}) {
    return this.client.request(x.MOVIES.DETAILS + e, this.withDefaults(t));
  }
  async now_playing(e = {}) {
    return this.client.request(x.MOVIES.DETAILS + x.MOVIES.NOW_PLAYING, this.withDefaults(e));
  }
  async popular(e = {}) {
    return this.fetch_movie_list(x.MOVIES.POPULAR, e);
  }
  async top_rated(e = {}) {
    return this.fetch_movie_list(x.MOVIES.TOP_RATED, e);
  }
  async upcoming(e = {}) {
    return this.client.request(x.MOVIES.DETAILS + x.MOVIES.UPCOMING, this.withDefaults(e));
  }
};
var P = class extends C {
  moviePath(e) {
    return `${x.MOVIES.DETAILS}/${e}`;
  }
  movieSubPath(e, t) {
    return `${this.moviePath(e)}${t}`;
  }
  async details(e) {
    let { language: t = this.defaultOptions.language, movie_id: n, ...r } = e, i = this.moviePath(n);
    return this.client.request(i, this.injectImageLanguageForAppends({ language: t, ...r }));
  }
  async alternative_titles(e) {
    let { movie_id: t, ...n } = e, r = this.movieSubPath(t, x.MOVIES.ALTERNATIVE_TITLES);
    return this.client.request(r, n);
  }
  async credits(e) {
    let { movie_id: t, language: n = this.defaultOptions.language, ...r } = e, i = this.movieSubPath(t, x.MOVIES.CREDITS);
    return this.client.request(i, { language: n, ...r });
  }
  async external_ids(e) {
    let t = this.movieSubPath(e.movie_id, x.MOVIES.EXTERNAL_IDS);
    return this.client.request(t);
  }
  async keywords(e) {
    let t = this.movieSubPath(e.movie_id, x.MOVIES.KEYWORDS);
    return this.client.request(t);
  }
  async changes(e) {
    let { movie_id: t, ...n } = e, r = this.movieSubPath(t, x.MOVIES.CHANGES);
    return this.client.request(r, n);
  }
  async images(e) {
    let { movie_id: t, language: n = this.defaultOptions.language, ...r } = e, i = this.movieSubPath(t, x.MOVIES.IMAGES);
    return this.client.request(i, this.injectImageLanguage({ language: n, ...r }));
  }
  async latest() {
    let e = `${x.MOVIES.DETAILS}${x.MOVIES.LATEST}`;
    return this.client.request(e);
  }
  async recommendations(e) {
    let { movie_id: t, language: n = this.defaultOptions.language, ...r } = e, i = this.movieSubPath(t, x.MOVIES.RECOMMENDATIONS);
    return this.client.request(i, { language: n, ...r });
  }
  async release_dates(e) {
    let t = this.movieSubPath(e.movie_id, x.MOVIES.RELEASE_DATES);
    return this.client.request(t);
  }
  async reviews(e) {
    let { movie_id: t, language: n = this.defaultOptions.language, ...r } = e, i = this.movieSubPath(t, x.MOVIES.REVIEWS);
    return this.client.request(i, { language: n, ...r });
  }
  async similar(e) {
    let { movie_id: t, language: n = this.defaultOptions.language, ...r } = e, i = this.movieSubPath(t, x.MOVIES.SIMILAR);
    return this.client.request(i, { language: n, ...r });
  }
  async translations(e) {
    let t = this.movieSubPath(e.movie_id, x.MOVIES.TRANSLATIONS);
    return this.client.request(t);
  }
  async videos(e) {
    let { movie_id: t, language: n = this.defaultOptions.language, ...r } = e, i = this.movieSubPath(t, x.MOVIES.VIDEOS);
    return this.client.request(i, { language: n, ...r });
  }
  async watch_providers(e) {
    let t = this.movieSubPath(e.movie_id, x.MOVIES.WATCH_PROVIDERS);
    return this.client.request(t);
  }
};
var F = class extends C {
  async collections(e) {
    return this.client.request(x.SEARCH.COLLECTION, this.applyDefaults(e));
  }
  async movies(e) {
    return this.client.request(x.SEARCH.MOVIE, this.applyDefaults(e));
  }
  async company(e) {
    return this.client.request(x.SEARCH.COMPANY, this.applyDefaults(e));
  }
  async keyword(e) {
    return this.client.request(x.SEARCH.KEYWORD, this.applyDefaults(e));
  }
  async person(e) {
    return this.client.request(x.SEARCH.PERSON, this.applyDefaults(e));
  }
  async tv_series(e) {
    return this.client.request(x.SEARCH.TV, this.applyDefaults(e));
  }
  async multi(e) {
    return this.client.request(x.SEARCH.MULTI, this.applyDefaults(e));
  }
};
var I = class extends C {
  seriesPath(e) {
    return `${x.TV_SERIES.DETAILS}/${e}`;
  }
  seriesSubPath(e, t) {
    return `${this.seriesPath(e)}${t}`;
  }
  async details(e) {
    let { language: t = this.defaultOptions.language, series_id: n, ...r } = e, i = this.seriesPath(n);
    return this.client.request(i, this.injectImageLanguageForAppends({ language: t, ...r }));
  }
  async aggregate_credits(e) {
    let { language: t = this.defaultOptions.language, series_id: n, ...r } = e, i = this.seriesSubPath(n, x.TV_SERIES.AGGREGATE_CREDITS);
    return this.client.request(i, { language: t, ...r });
  }
  async alternative_titles(e) {
    let t = this.seriesSubPath(e.series_id, x.TV_SERIES.ALTERNATIVE_TITLES);
    return this.client.request(t);
  }
  async changes(e) {
    let { series_id: t, ...n } = e, r = this.seriesSubPath(t, x.TV_SERIES.CHANGES);
    return this.client.request(r, { ...n });
  }
  async content_ratings(e) {
    let t = this.seriesSubPath(e.series_id, x.TV_SERIES.CONTENT_RATINGS);
    return this.client.request(t);
  }
  async credits(e) {
    let { language: t = this.defaultOptions.language, series_id: n, ...r } = e, i = this.seriesSubPath(n, x.TV_SERIES.CREDITS);
    return this.client.request(i, { language: t, ...r });
  }
  async episode_groups(e) {
    let t = this.seriesSubPath(e.series_id, x.TV_SERIES.EPISODE_GROUPS);
    return this.client.request(t);
  }
  async external_ids(e) {
    let t = this.seriesSubPath(e.series_id, x.TV_SERIES.EXTERNAL_IDS);
    return this.client.request(t);
  }
  async images(e) {
    let { language: t = this.defaultOptions.language, series_id: n, ...r } = e, i = this.seriesSubPath(n, x.TV_SERIES.IMAGES);
    return this.client.request(i, this.injectImageLanguage({ language: t, ...r }));
  }
  async keywords(e) {
    let t = this.seriesSubPath(e.series_id, x.TV_SERIES.KEYWORDS);
    return this.client.request(t);
  }
  async latest() {
    let e = `${x.TV_SERIES.DETAILS}${x.TV_SERIES.LATEST}`;
    return this.client.request(e);
  }
  async lists(e) {
    let { language: t = this.defaultOptions.language, series_id: n, ...r } = e, i = this.seriesSubPath(n, x.TV_SERIES.LISTS);
    return this.client.request(i, { language: t, ...r });
  }
  async recommendations(e) {
    let { language: t = this.defaultOptions.language, series_id: n, ...r } = e, i = this.seriesSubPath(n, x.TV_SERIES.RECOMMENDATIONS);
    return this.client.request(i, { language: t, ...r });
  }
  async reviews(e) {
    let { language: t = this.defaultOptions.language, series_id: n, ...r } = e, i = this.seriesSubPath(n, x.TV_SERIES.REVIEWS);
    return this.client.request(i, { language: t, ...r });
  }
  async screened_theatrically(e) {
    let t = this.seriesSubPath(e.series_id, x.TV_SERIES.SCREENED_THEATRICALLY);
    return this.client.request(t);
  }
  async similar(e) {
    let { language: t = this.defaultOptions.language, series_id: n, ...r } = e, i = this.seriesSubPath(n, x.TV_SERIES.SIMILAR);
    return this.client.request(i, { language: t, ...r });
  }
  async translations(e) {
    let t = this.seriesSubPath(e.series_id, x.TV_SERIES.TRANSLATIONS);
    return this.client.request(t);
  }
  async videos(e) {
    let t = this.seriesSubPath(e.series_id, x.TV_SERIES.VIDEOS);
    return this.client.request(t);
  }
  async watch_providers(e) {
    let t = this.seriesSubPath(e.series_id, x.TV_SERIES.WATCH_PROVIDERS);
    return this.client.request(t);
  }
};
var L = class extends C {
  withDefaults(e) {
    let { language: t = this.defaultOptions.language, timezone: n = this.defaultOptions.timezone, ...r } = e;
    return { language: t, timezone: n, ...r };
  }
  fetch_tv_series_list(e, t = {}) {
    return this.client.request(x.TV_SERIES.DETAILS + e, this.withDefaults(t));
  }
  async airing_today(e = {}) {
    return this.fetch_tv_series_list(x.TV_SERIES.AIRING_TODAY, e);
  }
  async on_the_air(e = {}) {
    return this.fetch_tv_series_list(x.TV_SERIES.ON_THE_AIR, e);
  }
  async popular(e = {}) {
    return this.fetch_tv_series_list(x.TV_SERIES.POPULAR, e);
  }
  async top_rated(e = {}) {
    return this.fetch_tv_series_list(x.TV_SERIES.TOP_RATED, e);
  }
};
var R = class extends C {
  async movie_providers(e) {
    let t = e?.language ?? this.defaultOptions.language, n = t === undefined ? e : { ...e, language: t };
    return this.client.request(x.WATCH_PROVIDERS.MOVIE, n);
  }
  async tv_providers(e) {
    let t = e?.language ?? this.defaultOptions.language, n = t === undefined ? e : { ...e, language: t };
    return this.client.request(x.WATCH_PROVIDERS.TV, n);
  }
  async available_regions(e) {
    let t = e?.language ?? this.defaultOptions.language, n = t === undefined ? e : { ...e, language: t };
    return this.client.request(x.WATCH_PROVIDERS.REGIONS, n);
  }
};
var z = class extends C {
  networkPath(e) {
    return `${x.NETWORKS.DETAILS}/${e}`;
  }
  async details(e) {
    let t = this.networkPath(e.network_id);
    return this.client.request(t);
  }
  async alternative_names(e) {
    let t = `${this.networkPath(e.network_id)}${x.NETWORKS.ALTERNATIVE_NAMES}`;
    return this.client.request(t);
  }
  async images(e) {
    let t = `${this.networkPath(e.network_id)}${x.NETWORKS.IMAGES}`;
    return this.client.request(t);
  }
};
var B = class extends C {
  episodePath(e) {
    return `${x.TV_SERIES.DETAILS}/${e.series_id}${x.TV_SEASONS.DETAILS}/${e.season_number}${x.TV_EPISODES.DETAILS}/${e.episode_number}`;
  }
  episodeSubPath(e, t) {
    return `${this.episodePath(e)}${t}`;
  }
  async details(e) {
    let { language: t = this.defaultOptions.language, series_id: n, season_number: r, episode_number: i, ...a } = e, o = this.episodePath({ series_id: n, season_number: r, episode_number: i });
    return this.client.request(o, this.injectImageLanguageForAppends({ language: t, ...a }));
  }
  async changes(e) {
    let { episode_id: t, ...n } = e, r = `${x.TV_SERIES.DETAILS}${x.TV_EPISODES.DETAILS}/${t}${x.TV_EPISODES.CHANGES}`;
    return this.client.request(r, { ...n });
  }
  async credits(e) {
    let { language: t = this.defaultOptions.language, ...n } = e, r = this.episodeSubPath(n, x.TV_EPISODES.CREDITS);
    return this.client.request(r, { language: t });
  }
  async external_ids(e) {
    let t = this.episodeSubPath(e, x.TV_EPISODES.EXTERNAL_IDS);
    return this.client.request(t);
  }
  async images(e) {
    let { language: t = this.defaultOptions.language, include_image_language: n, ...r } = e, i = this.episodeSubPath(r, x.TV_EPISODES.IMAGES);
    return this.client.request(i, this.injectImageLanguage({ language: t, include_image_language: n }));
  }
  async translations(e) {
    let t = this.episodeSubPath(e, x.TV_EPISODES.TRANSLATIONS);
    return this.client.request(t);
  }
  async videos(e) {
    let t = this.episodeSubPath(e, x.TV_EPISODES.VIDEOS);
    return this.client.request(t);
  }
};
var V = class extends C {
  async details(e) {
    let t = `${x.TV_EPISODE_GROUPS.DETAILS}/${e.episode_group_id}`;
    return this.client.request(t);
  }
};
var H = class extends C {
  seasonPath(e) {
    return `${x.TV_SERIES.DETAILS}/${e.series_id}${x.TV_SEASONS.DETAILS}/${e.season_number}`;
  }
  seasonSubPath(e, t) {
    return `${this.seasonPath(e)}${t}`;
  }
  async details(e) {
    let { language: t = this.defaultOptions.language, series_id: n, season_number: r, ...i } = e, a = this.seasonPath({ series_id: n, season_number: r });
    return this.client.request(a, this.injectImageLanguageForAppends({ language: t, ...i }));
  }
  async aggregate_credits(e) {
    let { language: t = this.defaultOptions.language, ...n } = e, r = this.seasonSubPath(n, x.TV_SEASONS.AGGREGATE_CREDITS);
    return this.client.request(r, { language: t });
  }
  async changes(e) {
    let { season_id: t, ...n } = e, r = `${x.TV_SERIES.DETAILS}${x.TV_SEASONS.DETAILS}/${t}${x.TV_SEASONS.CHANGES}`;
    return this.client.request(r, { ...n });
  }
  async credits(e) {
    let { language: t = this.defaultOptions.language, ...n } = e, r = this.seasonSubPath(n, x.TV_SEASONS.CREDITS);
    return this.client.request(r, { language: t });
  }
  async external_ids(e) {
    let t = this.seasonSubPath(e, x.TV_SEASONS.EXTERNAL_IDS);
    return this.client.request(t);
  }
  async images(e) {
    let { language: t = this.defaultOptions.language, include_image_language: n, ...r } = e, i = this.seasonSubPath(r, x.TV_SEASONS.IMAGES);
    return this.client.request(i, this.injectImageLanguage({ language: t, include_image_language: n }));
  }
  async translations(e) {
    let t = this.seasonSubPath(e, x.TV_SEASONS.TRANSLATIONS);
    return this.client.request(t);
  }
  async videos(e) {
    let { language: t = this.defaultOptions.language, include_video_language: n, ...r } = e, i = this.seasonSubPath(r, x.TV_SEASONS.VIDEOS);
    return this.client.request(i, { language: t, include_video_language: n });
  }
  async watch_providers(e) {
    let { language: t = this.defaultOptions.language, ...n } = e, r = this.seasonSubPath(n, x.TV_SEASONS.WATCH_PROVIDERS);
    return this.client.request(r, { language: t });
  }
};
var U = class extends C {
  async all(e) {
    let { time_window: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(`${x.TRENDING.ALL}/${t}`, { language: n, ...r });
  }
  async movies(e) {
    let { time_window: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(`${x.TRENDING.MOVIE}/${t}`, { language: n, ...r });
  }
  async tv(e) {
    let { time_window: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(`${x.TRENDING.TV}/${t}`, { language: n, ...r });
  }
  async people(e) {
    let { time_window: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(`${x.TRENDING.PERSON}/${t}`, { language: n, ...r });
  }
};
var W = class extends C {
  async details(e) {
    return this.client.request(`${x.REVIEWS.DETAILS}/${e.review_id}`);
  }
};
var G = class extends C {
  async popular(e = {}) {
    return this.client.request(x.PEOPLE_LISTS.POPULAR, this.withLanguage(e));
  }
};
var K = class extends C {
  personPath(e) {
    return `${x.PEOPLE.DETAILS}/${e}`;
  }
  personSubPath(e, t) {
    return `${this.personPath(e)}${t}`;
  }
  async details(e) {
    let { language: t = this.defaultOptions.language, person_id: n, ...r } = e;
    return this.client.request(this.personPath(n), { language: t, ...r });
  }
  async changes(e) {
    let { person_id: t, ...n } = e;
    return this.client.request(this.personSubPath(t, x.PEOPLE.CHANGES), n);
  }
  async combined_credits(e) {
    let { language: t = this.defaultOptions.language, person_id: n, ...r } = e;
    return this.client.request(this.personSubPath(n, x.PEOPLE.COMBINED_CREDITS), { language: t, ...r });
  }
  async external_ids(e) {
    return this.client.request(this.personSubPath(e.person_id, x.PEOPLE.EXTERNAL_IDS));
  }
  async images(e) {
    return this.client.request(this.personSubPath(e.person_id, x.PEOPLE.IMAGES));
  }
  async latest() {
    return this.client.request(`${x.PEOPLE.DETAILS}${x.PEOPLE.LATEST}`);
  }
  async movie_credits(e) {
    let { language: t = this.defaultOptions.language, person_id: n, ...r } = e;
    return this.client.request(this.personSubPath(n, x.PEOPLE.MOVIE_CREDITS), { language: t, ...r });
  }
  async tagged_images(e) {
    let { person_id: t, ...n } = e;
    return this.client.request(this.personSubPath(t, x.PEOPLE.TAGGED_IMAGES), n);
  }
  async translations(e) {
    return this.client.request(this.personSubPath(e.person_id, x.PEOPLE.TRANSLATIONS));
  }
  async tv_credits(e) {
    let { language: t = this.defaultOptions.language, person_id: n, ...r } = e;
    return this.client.request(this.personSubPath(n, x.PEOPLE.TV_CREDITS), { language: t, ...r });
  }
};
var q = class extends C {
  accountPath(e) {
    return `${x.ACCOUNT.DETAILS}/${e}`;
  }
  accountSubPath(e, t) {
    return `${this.accountPath(e)}${t}`;
  }
  async details(e) {
    let { account_id: t, ...n } = e;
    return this.client.request(this.accountPath(t), n);
  }
  async add_favorite(e, t) {
    let { account_id: n, ...r } = e;
    return this.client.mutate(`POST`, this.accountSubPath(n, x.ACCOUNT.ADD_FAVORITE), t, r);
  }
  async add_to_watchlist(e, t) {
    let { account_id: n, ...r } = e;
    return this.client.mutate(`POST`, this.accountSubPath(n, x.ACCOUNT.ADD_TO_WATCHLIST), t, r);
  }
  async favorite_movies(e) {
    let { account_id: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(this.accountSubPath(t, x.ACCOUNT.FAVORITE_MOVIES), { language: n, ...r });
  }
  async favorite_tv(e) {
    let { account_id: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(this.accountSubPath(t, x.ACCOUNT.FAVORITE_TV), { language: n, ...r });
  }
  async watchlist_movies(e) {
    let { account_id: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(this.accountSubPath(t, x.ACCOUNT.WATCHLIST_MOVIES), { language: n, ...r });
  }
  async watchlist_tv(e) {
    let { account_id: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(this.accountSubPath(t, x.ACCOUNT.WATCHLIST_TV), { language: n, ...r });
  }
  async rated_movies(e) {
    let { account_id: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(this.accountSubPath(t, x.ACCOUNT.RATED_MOVIES), { language: n, ...r });
  }
  async rated_tv(e) {
    let { account_id: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(this.accountSubPath(t, x.ACCOUNT.RATED_TV), { language: n, ...r });
  }
  async rated_tv_episodes(e) {
    let { account_id: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(this.accountSubPath(t, x.ACCOUNT.RATED_TV_EPISODES), { language: n, ...r });
  }
  async lists(e) {
    let { account_id: t, ...n } = e;
    return this.client.request(this.accountSubPath(t, x.ACCOUNT.LISTS), n);
  }
};
var J = class extends C {
  async validate_key() {
    return this.client.request(x.AUTHENTICATION.VALIDATE);
  }
  async create_guest_session() {
    return this.client.request(x.AUTHENTICATION.GUEST_SESSION);
  }
  async create_request_token() {
    return this.client.request(x.AUTHENTICATION.REQUEST_TOKEN);
  }
  async create_session(e) {
    return this.client.mutate(`POST`, x.AUTHENTICATION.CREATE_SESSION, e);
  }
  async create_session_with_login(e) {
    return this.client.mutate(`POST`, x.AUTHENTICATION.CREATE_SESSION_WITH_LOGIN, e);
  }
  async delete_session(e) {
    return this.client.mutate(`DELETE`, x.AUTHENTICATION.DELETE_SESSION, e);
  }
};
var Y = class extends C {
  guestSessionPath(e) {
    return `${x.GUEST_SESSIONS.DETAILS}/${e}`;
  }
  guestSessionSubPath(e, t) {
    return `${this.guestSessionPath(e)}${t}`;
  }
  async rated_movies(e) {
    let { guest_session_id: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(this.guestSessionSubPath(t, x.GUEST_SESSIONS.RATED_MOVIES), { language: n, ...r });
  }
  async rated_tv(e) {
    let { guest_session_id: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(this.guestSessionSubPath(t, x.GUEST_SESSIONS.RATED_TV), { language: n, ...r });
  }
  async rated_tv_episodes(e) {
    let { guest_session_id: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(this.guestSessionSubPath(t, x.GUEST_SESSIONS.RATED_TV_EPISODES), { language: n, ...r });
  }
};
var X = class extends C {
  listPath(e) {
    return `${x.LISTS.DETAILS}/${e}`;
  }
  listSubPath(e, t) {
    return `${this.listPath(e)}${t}`;
  }
  async details(e) {
    let { list_id: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(this.listPath(t), { language: n, ...r });
  }
  async create(e, t) {
    return this.client.mutate(`POST`, x.LISTS.DETAILS, t, e);
  }
  async delete(e) {
    let { list_id: t, ...n } = e;
    return this.client.mutate(`DELETE`, this.listPath(t), undefined, n);
  }
  async add_movie(e, t) {
    let { list_id: n, ...r } = e;
    return this.client.mutate(`POST`, this.listSubPath(n, x.LISTS.ADD_ITEM), t, r);
  }
  async remove_movie(e, t) {
    let { list_id: n, ...r } = e;
    return this.client.mutate(`POST`, this.listSubPath(n, x.LISTS.REMOVE_ITEM), t, r);
  }
  async check_item_status(e) {
    let { list_id: t, language: n = this.defaultOptions.language, ...r } = e;
    return this.client.request(this.listSubPath(t, x.LISTS.ITEM_STATUS), { language: n, ...r });
  }
  async clear(e) {
    let { list_id: t, ...n } = e;
    return this.client.mutate(`POST`, this.listSubPath(t, x.LISTS.CLEAR), undefined, n);
  }
};
var Z = class extends C {
  async create_request_token(e) {
    return this.client.mutate(`POST`, S.AUTH.REQUEST_TOKEN, e ?? {});
  }
  async create_access_token(e) {
    return this.client.mutate(`POST`, S.AUTH.ACCESS_TOKEN, e);
  }
  async delete_access_token(e) {
    return this.client.mutate(`DELETE`, S.AUTH.ACCESS_TOKEN, e);
  }
};
var Q = class extends C {
};
var de = class extends C {
  listPath(e) {
    return `${S.LISTS.DETAILS}/${e}`;
  }
  async create(e) {
    return this.client.mutate(`POST`, S.LISTS.DETAILS, e);
  }
  async details({ list_id: e, ...t }) {
    return this.client.request(this.listPath(e), this.withLanguage(t));
  }
  async update({ list_id: e, ...t }) {
    return this.client.mutate(`PUT`, this.listPath(e), t);
  }
  async delete({ list_id: e }) {
    return this.client.mutate(`DELETE`, this.listPath(e), {});
  }
  async add_items(e, t) {
    return this.client.mutate(`POST`, `${this.listPath(e)}${S.LISTS.ITEMS}`, t);
  }
  async update_items(e, t) {
    return this.client.mutate(`PUT`, `${this.listPath(e)}${S.LISTS.ITEMS}`, t);
  }
  async remove_items(e, t) {
    return this.client.mutate(`DELETE`, `${this.listPath(e)}${S.LISTS.ITEMS}`, t);
  }
  async item_status({ list_id: e, ...t }) {
    return this.client.request(`${this.listPath(e)}${S.LISTS.ITEM_STATUS}`, t);
  }
  async clear(e) {
    return this.client.mutate(`GET`, `${this.listPath(e)}${S.LISTS.CLEAR}`);
  }
};
var $ = class {
  client;
  auth;
  account;
  lists;
  constructor(e, t = {}) {
    if (!e)
      throw Error(l.NO_ACCESS_TOKEN);
    this.client = new b(e, { ...t, version: 4 }), this.auth = new Z(this.client, t), this.account = new Q(this.client, t), this.lists = new de(this.client, t);
  }
};
var fe = class {
  client;
  accessToken;
  options;
  movies;
  movie_lists;
  search;
  images;
  configuration;
  genres;
  keywords;
  tv_lists;
  tv_series;
  watch_providers;
  certifications;
  changes;
  companies;
  credits;
  collections;
  discover;
  find;
  networks;
  tv_episodes;
  tv_episode_groups;
  tv_seasons;
  trending;
  reviews;
  people_lists;
  people;
  account;
  authentication;
  guest_sessions;
  lists;
  get v4() {
    if (!c2(this.accessToken))
      throw Error(l.V4_REQUIRES_JWT);
    return this._v4 ||= new $(this.accessToken, this.options), this._v4;
  }
  _v4;
  get cache() {
    if (!this.options.cache)
      return;
    let e = this.client;
    return { clear() {
      e.clearCache();
    }, invalidate(t, n) {
      return e.invalidateCache(t, n);
    }, get size() {
      return e.cacheSize;
    } };
  }
  constructor(t, n = {}) {
    if (!t)
      throw Error(l.NO_ACCESS_TOKEN);
    this.accessToken = t, this.options = n, this.client = new b(t, { logger: n.logger, deduplication: n.deduplication, images: n.images, rate_limit: n.rate_limit, retry: n.retry, cache: n.cache, interceptors: n.interceptors }), this.movies = new P(this.client, this.options), this.movie_lists = new N(this.client, this.options), this.search = new F(this.client, this.options), this.images = new _(this.options.images), this.configuration = new k(this.client, this.options), this.genres = new M(this.client, this.options), this.keywords = new ue(this.client, this.options), this.tv_lists = new L(this.client, this.options), this.tv_series = new I(this.client, this.options), this.watch_providers = new R(this.client, this.options), this.certifications = new w(this.client, this.options), this.changes = new T(this.client, this.options), this.companies = new E(this.client, this.options), this.credits = new D(this.client, this.options), this.collections = new O(this.client, this.options), this.discover = new A(this.client, this.options), this.find = new j(this.client, this.options), this.networks = new z(this.client, this.options), this.tv_episodes = new B(this.client, this.options), this.tv_episode_groups = new V(this.client, this.options), this.tv_seasons = new H(this.client, this.options), this.trending = new U(this.client, this.options), this.reviews = new W(this.client, this.options), this.people_lists = new G(this.client, this.options), this.people = new K(this.client, this.options), this.account = new q(this.client, this.options), this.authentication = new J(this.client, this.options), this.guest_sessions = new Y(this.client, this.options), this.lists = new X(this.client, this.options);
  }
};

// plugins/tmdb/src/tmdb.ts
function toLanguage(value) {
  return isLanguage(value) ? value : "en-US";
}
function isLanguage(value) {
  return value.trim().length > 0;
}

class TMDBApi {
  IMAGE_BASE = "https://image.tmdb.org/t/p/original";
  client;
  fallbackClient;
  language;
  fallbackLanguage;
  searchLanguage;
  constructor(apiKey, language = "pl-PL", searchLanguage = "en-US", fallbackLanguage = "en-US") {
    this.language = language;
    this.fallbackLanguage = fallbackLanguage;
    this.searchLanguage = searchLanguage;
    this.client = new fe(apiKey, { language: toLanguage(language) });
    if (fallbackLanguage && fallbackLanguage !== language) {
      this.fallbackClient = new fe(apiKey, { language: toLanguage(fallbackLanguage) });
    }
  }
  getImagePath(path) {
    return path ? `${this.IMAGE_BASE}${path}` : undefined;
  }
  getGender(gender) {
    if (gender === 1)
      return "female";
    if (gender === 2)
      return "male";
    return "other";
  }
  castParse(cast) {
    return cast.map((item) => ({
      id: item.id.toString(),
      name: item.name,
      profilePath: this.getImagePath(item.profile_path),
      gender: this.getGender(item.gender),
      popularity: item.popularity,
      role: item.known_for_department,
      character: item.character,
      order: item.order
    }));
  }
  basicMetadataParse(data) {
    return {
      productionCompanies: data.production_companies?.map((c) => ({
        id: c.id.toString(),
        name: c.name
      })),
      genres: data.genres.map((g) => ({
        id: g.id.toString(),
        name: g.name
      })),
      cast: this.castParse(data.cast),
      crew: data.crew.map((item) => ({
        id: item.id.toString(),
        name: item.name,
        profilePath: this.getImagePath(item.profile_path),
        gender: this.getGender(item.gender),
        popularity: item.popularity,
        job: item.job,
        department: item.department
      })),
      keywords: data.keywords.map((k) => ({
        id: k.id.toString(),
        name: k.name
      }))
    };
  }
}

// plugins/tmdb/src/discovery.ts
function toSearchResult(api, item) {
  return {
    externalId: item.id.toString(),
    title: item.title ?? item.name ?? "",
    originalTitle: item.original_title ?? item.original_name,
    originalLanguage: item.original_language,
    releaseDate: item.release_date ?? item.first_air_date ?? "",
    posterPath: api.getImagePath(item.poster_path),
    backdropPath: api.getImagePath(item.backdrop_path),
    overview: item.overview,
    popularity: item.popularity,
    voteAverage: item.vote_average,
    voteCount: item.vote_count
  };
}
function mapPage(api, response) {
  return {
    page: response.page,
    totalPages: response.total_pages,
    totalResults: response.total_results,
    items: (response.results ?? []).map((item) => toSearchResult(api, item))
  };
}
function emptyPage(page) {
  return { items: [], page, totalPages: 0, totalResults: 0 };
}
async function fetchRecommendations(api, request, language, page) {
  const numericId = request.externalId ? Number(request.externalId) : Number.NaN;
  if (!Number.isFinite(numericId))
    return emptyPage(page);
  const client = api.client;
  const isRecommendations = request.category === "recommendations";
  if (request.type === "tv_show") {
    const params = { series_id: numericId, page, language };
    const response = isRecommendations ? await client.tv_series.recommendations(params) : await client.tv_series.similar(params);
    return mapPage(api, response);
  }
  const params = { movie_id: numericId, page, language };
  const response = isRecommendations ? await client.movies.recommendations(params) : await client.movies.similar(params);
  return mapPage(api, response);
}
async function fetchDiscover(api, request, language, page) {
  const client = api.client;
  const genreFilter = request.genreId ? { with_genres: request.genreId } : {};
  if (request.type === "tv_show") {
    return mapPage(api, await client.discover.tv({
      page,
      language,
      ...genreFilter,
      ...request.year ? { first_air_date_year: request.year } : {},
      sort_by: "popularity.desc"
    }));
  }
  return mapPage(api, await client.discover.movie({
    page,
    language,
    ...genreFilter,
    ...request.year ? { primary_release_year: request.year } : {},
    sort_by: "popularity.desc"
  }));
}
async function fetchCategory(api, request, language, page) {
  const client = api.client;
  const isTv = request.type === "tv_show";
  switch (request.category) {
    case "trending": {
      const params = { time_window: request.window ?? "week", page, language };
      return isTv ? mapPage(api, await client.trending.tv(params)) : mapPage(api, await client.trending.movies(params));
    }
    case "popular":
      return isTv ? mapPage(api, await client.tv_lists.popular({ page, language })) : mapPage(api, await client.movie_lists.popular({ page, language }));
    case "top_rated":
      return isTv ? mapPage(api, await client.tv_lists.top_rated({ page, language })) : mapPage(api, await client.movie_lists.top_rated({ page, language }));
    case "now_playing":
      return isTv ? mapPage(api, await client.tv_lists.on_the_air({ page, language })) : mapPage(api, await client.movie_lists.now_playing({ page, language }));
    case "upcoming":
      return isTv ? mapPage(api, await client.tv_lists.airing_today({ page, language })) : mapPage(api, await client.movie_lists.upcoming({ page, language }));
    case "recommendations":
    case "similar":
      return emptyPage(page);
    default:
      return emptyPage(page);
  }
}
function discoverTmdb(api, request) {
  const language = toLanguage(request.language ?? api.language);
  const page = request.page && request.page > 0 ? request.page : 1;
  if (request.category === "recommendations" || request.category === "similar") {
    return fetchRecommendations(api, request, language, page);
  }
  if (request.genreId || request.year) {
    return fetchDiscover(api, request, language, page);
  }
  return fetchCategory(api, request, language, page);
}
async function getTmdbGenres(api, type) {
  const language = toLanguage(api.language);
  const response = type === "tv_show" ? await api.client.genres.tv_list({ language }) : await api.client.genres.movie_list({ language });
  return response.genres.map((genre) => ({ id: genre.id.toString(), name: genre.name }));
}

// plugins/tmdb/src/routes/details-episode.ts
async function getDetailsEpisode(api, externalId, seasonNumber, episodeNumber) {
  const tvShowID = Number(externalId);
  const details = await api.client.tv_episodes.details({
    series_id: tvShowID,
    season_number: seasonNumber,
    episode_number: episodeNumber,
    append_to_response: ["credits"]
  });
  let epName = details.name;
  let epOverview = details.overview;
  let hasMissingTranslation = false;
  if (!(epName && epOverview) && api.fallbackClient) {
    try {
      const fallbackDetails = await api.fallbackClient.tv_episodes.details({
        series_id: tvShowID,
        season_number: seasonNumber,
        episode_number: episodeNumber
      });
      if (!epOverview && fallbackDetails.overview) {
        epOverview = fallbackDetails.overview;
        hasMissingTranslation = true;
      }
      if (!epName && fallbackDetails.name) {
        epName = fallbackDetails.name;
        hasMissingTranslation = true;
      }
    } catch {}
  }
  if (!(epOverview && details.overview)) {
    hasMissingTranslation = true;
  }
  return {
    externalId: details.id.toString(),
    episodeNumber: details.episode_number,
    seasonNumber: details.season_number,
    name: epName || `Episode ${details.episode_number}`,
    overview: epOverview || undefined,
    airDate: details.air_date,
    status: undefined,
    voteAverage: details.vote_average,
    voteCount: details.vote_count,
    thumbnailPath: api.getImagePath(details.still_path),
    hasMissingTranslation,
    cast: details.credits.cast.map((item) => ({
      id: item.id.toString(),
      name: item.name,
      gender: api.getGender(item.gender),
      popularity: item.popularity,
      profilePath: api.getImagePath(item.profile_path),
      role: item.known_for_department,
      character: item.character,
      order: item.order
    }))
  };
}

// plugins/tmdb/src/routes/details-movie.ts
async function getDetailsMovie(api, id) {
  const movie_id = Number(id);
  const details = await api.client.movies.details({
    movie_id,
    append_to_response: ["keywords", "credits"]
  });
  let hasMissingTranslation = false;
  let title = details.title;
  let overview = details.overview;
  let tagline = details.tagline;
  if (!(overview && title && tagline) && api.fallbackClient) {
    try {
      const fallbackDetails = await api.fallbackClient.movies.details({
        movie_id
      });
      if (!overview && fallbackDetails.overview) {
        overview = fallbackDetails.overview;
        hasMissingTranslation = true;
      }
      if (!title && fallbackDetails.title) {
        title = fallbackDetails.title;
        hasMissingTranslation = true;
      }
      if (!tagline && fallbackDetails.tagline) {
        tagline = fallbackDetails.tagline;
      }
    } catch {}
  }
  if (!(overview && details.overview)) {
    hasMissingTranslation = true;
  }
  return {
    externalId: id,
    title: title || details.original_title || "Unknown",
    originalTitle: details.original_title,
    overview: overview ?? undefined,
    tagline: tagline ?? undefined,
    releaseDate: details.release_date,
    status: details.status,
    budget: details.budget,
    revenue: details.revenue,
    voteAverage: details.vote_average,
    voteCount: details.vote_count,
    ratings: details.vote_average > 0 ? [{ source: "tmdb", label: "TMDB", value: details.vote_average, maxValue: 10, votes: details.vote_count }] : undefined,
    popularity: details.popularity,
    posterPath: api.getImagePath(details.poster_path),
    backdropPath: api.getImagePath(details.backdrop_path),
    logoPath: undefined,
    hasMissingTranslation,
    seasons: undefined,
    collection: details.belongs_to_collection ? [
      {
        id: details.belongs_to_collection.id.toString(),
        name: details.belongs_to_collection.name
      }
    ] : undefined,
    ...api.basicMetadataParse({
      production_companies: details.production_companies,
      genres: details.genres,
      cast: details.credits.cast,
      crew: details.credits.crew,
      keywords: details.keywords.keywords
    })
  };
}

// plugins/tmdb/src/routes/details-season.ts
async function getDetailsSeason(api, externalId, seasonNumber) {
  const series_id = Number(externalId);
  const details = await api.client.tv_seasons.details({ series_id, season_number: seasonNumber });
  let fallbackDetails = null;
  let seasonOverview = details.overview;
  let seasonName = details.name;
  let hasMissingTranslation = false;
  if (!(seasonOverview && seasonName) && api.fallbackClient) {
    try {
      fallbackDetails = await api.fallbackClient.tv_seasons.details({ series_id, season_number: seasonNumber });
      if (!seasonOverview && fallbackDetails.overview) {
        seasonOverview = fallbackDetails.overview;
        hasMissingTranslation = true;
      }
      if (!seasonName && fallbackDetails.name) {
        seasonName = fallbackDetails.name;
        hasMissingTranslation = true;
      }
    } catch {}
  }
  if (!seasonOverview) {
    hasMissingTranslation = true;
  }
  return {
    externalId: details.id.toString(),
    seasonNumber: details.season_number,
    name: seasonName || (details.season_number === 0 ? "Specials" : `Season ${details.season_number}`),
    overview: seasonOverview || undefined,
    status: undefined,
    airDate: details.air_date,
    voteAverage: undefined,
    voteCount: undefined,
    posterPath: api.getImagePath(details.poster_path),
    episodes: details.episodes.map((i) => {
      let epOverview = i.overview;
      let epName = i.name;
      if (!(epOverview && epName) && fallbackDetails?.episodes) {
        const fbEp = fallbackDetails.episodes.find((e) => e.episode_number === i.episode_number);
        if (!epOverview && fbEp?.overview) {
          epOverview = fbEp.overview;
          hasMissingTranslation = true;
        }
        if (!epName && fbEp?.name) {
          epName = fbEp.name;
          hasMissingTranslation = true;
        }
      }
      return {
        externalId: i.id.toString(),
        episodeNumber: i.episode_number,
        seasonNumber: i.season_number,
        name: epName || `Episode ${i.episode_number}`,
        overview: epOverview || undefined,
        airDate: i.air_date,
        status: undefined,
        voteAverage: i.vote_average,
        voteCount: i.vote_count,
        thumbnailPath: api.getImagePath(i.still_path),
        hasMissingTranslation: !i.overview,
        cast: i.guest_stars.map((item) => ({
          id: item.id.toString(),
          name: item.name,
          profilePath: api.getImagePath(item.profile_path),
          gender: api.getGender(item.gender),
          popularity: item.popularity,
          role: item.known_for_department,
          character: item.character,
          order: item.order
        }))
      };
    }),
    hasMissingTranslation
  };
}

// plugins/tmdb/src/routes/details-series.ts
async function getDetailsSeries(api, id) {
  const tvShowId = Number(id);
  const details = await api.client.tv_series.details({
    series_id: tvShowId,
    append_to_response: ["keywords", "credits"]
  });
  let hasMissingTranslation = false;
  let title = details.name;
  let overview = details.overview;
  let tagline = details.tagline;
  let fallbackDetails = null;
  if (!(overview && title && tagline) && api.fallbackClient) {
    try {
      fallbackDetails = await api.fallbackClient.tv_series.details({
        series_id: tvShowId,
        append_to_response: ["keywords", "credits"]
      });
      if (!overview && fallbackDetails.overview) {
        overview = fallbackDetails.overview;
        hasMissingTranslation = true;
      }
      if (!title && fallbackDetails.name) {
        title = fallbackDetails.name;
        hasMissingTranslation = true;
      }
      if (!tagline && fallbackDetails.tagline) {
        tagline = fallbackDetails.tagline;
      }
    } catch {}
  }
  if (!(overview && details.overview)) {
    hasMissingTranslation = true;
  }
  const seasons = details.seasons?.map((i) => {
    let seasonOverview = i.overview;
    let seasonName = i.name;
    if (!(seasonOverview && seasonName) && fallbackDetails?.seasons) {
      const fbSeason = fallbackDetails.seasons.find((s) => s.season_number === i.season_number);
      if (!seasonOverview && fbSeason?.overview) {
        seasonOverview = fbSeason.overview;
        hasMissingTranslation = true;
      }
      if (!seasonName && fbSeason?.name) {
        seasonName = fbSeason.name;
        hasMissingTranslation = true;
      }
    }
    if (!seasonOverview) {
      hasMissingTranslation = true;
    }
    return {
      externalId: i.id.toString(),
      seasonNumber: i.season_number,
      name: seasonName || (i.season_number === 0 ? "Specials" : `Season ${i.season_number}`),
      overview: seasonOverview || undefined,
      episodeCount: i.episode_count,
      airDate: i.air_date,
      status: undefined,
      voteAverage: undefined,
      voteCount: undefined,
      episodes: undefined,
      posterPath: api.getImagePath(i.poster_path)
    };
  });
  return {
    externalId: id,
    title: title || details.original_name || "Unknown",
    originalTitle: details.original_name,
    overview: overview ?? undefined,
    tagline: tagline ?? undefined,
    releaseDate: details.first_air_date,
    status: details.status,
    budget: undefined,
    revenue: undefined,
    voteAverage: details.vote_average,
    voteCount: details.vote_count,
    ratings: details.vote_average > 0 ? [{ source: "tmdb", label: "TMDB", value: details.vote_average, maxValue: 10, votes: details.vote_count }] : undefined,
    popularity: details.popularity,
    posterPath: api.getImagePath(details.poster_path),
    backdropPath: api.getImagePath(details.backdrop_path),
    logoPath: undefined,
    hasMissingTranslation,
    collection: undefined,
    seasons,
    ...api.basicMetadataParse({
      production_companies: details.production_companies,
      genres: details.genres,
      cast: details.credits.cast,
      crew: details.credits.crew,
      keywords: details.keywords.results
    })
  };
}

// plugins/tmdb/src/routes/search-movie.ts
async function searchMovie(api, query, year) {
  const searchLanguage = toLanguage(api.searchLanguage || api.language);
  let results = [];
  if (year) {
    const response = await api.client.search.movies({
      query,
      language: searchLanguage,
      primary_release_year: year.toString()
    });
    results = response.results;
  }
  if (results.length === 0) {
    const response = await api.client.search.movies({
      query,
      language: searchLanguage
    });
    results = response.results;
  }
  return results.map((item) => ({
    externalId: item.id.toString(),
    title: item.title,
    originalTitle: item.original_title,
    originalLanguage: item.original_language,
    releaseDate: item.release_date,
    posterPath: api.getImagePath(item.poster_path),
    overview: item.overview,
    popularity: item.popularity,
    voteAverage: item.vote_average,
    voteCount: item.vote_count
  }));
}

// plugins/tmdb/src/routes/search-series.ts
async function searchSeries(api, query, year) {
  const searchLanguage = toLanguage(api.searchLanguage || api.language);
  let results = [];
  if (year) {
    const response = await api.client.search.tv_series({
      query,
      language: searchLanguage,
      first_air_date_year: year
    });
    results = response.results;
  }
  if (results.length === 0) {
    const response = await api.client.search.tv_series({
      query,
      language: searchLanguage
    });
    results = response.results;
  }
  return results.map((item) => ({
    externalId: item.id.toString(),
    title: item.name,
    originalTitle: item.original_name,
    originalLanguage: item.original_language,
    releaseDate: item.first_air_date,
    posterPath: api.getImagePath(item.poster_path),
    overview: item.overview,
    popularity: item.popularity,
    voteAverage: item.vote_average,
    voteCount: item.vote_count
  }));
}

// plugins/tmdb/src/provider.ts
function createTmdbProvider(config) {
  let api;
  let logger;
  const getApi = () => {
    if (!api)
      throw new Error("TMDB provider has not been initialized");
    return api;
  };
  const provider = {
    id: "tmdb",
    name: "TMDB",
    version: "1.0.0",
    supportedTypes: ["movie", "tv_show"],
    initialize(context) {
      logger = context.logger;
      api = new TMDBApi(config.apiKey, config.language, config.searchLanguage, config.fallbackLanguage);
    },
    async search(type, query, year) {
      if (!query.trim())
        return [];
      try {
        if (type === "tv_show") {
          return await searchSeries(getApi(), query, year);
        }
        return await searchMovie(getApi(), query, year);
      } catch (error) {
        logger?.error("TMDB search failed", error, { type, query, year });
        return [];
      }
    },
    async getDetails(type, externalId) {
      try {
        if (type === "tv_show") {
          return await getDetailsSeries(getApi(), externalId);
        }
        return await getDetailsMovie(getApi(), externalId);
      } catch (error) {
        logger?.error("TMDB metadata details failed", error, { type, externalId });
        return null;
      }
    },
    async getImages(type, externalId) {
      try {
        const id = Number(externalId);
        const imageLanguages = ["pl", "en", "null"];
        const data = type === "movie" ? await getApi().client.movies.images({ movie_id: id, include_image_language: imageLanguages }) : await getApi().client.tv_series.images({ series_id: id, include_image_language: imageLanguages });
        return [
          ...data.posters.flatMap((image) => {
            const url = getApi().getImagePath(image.file_path);
            return url ? [
              {
                type: "poster",
                url,
                width: image.width,
                height: image.height,
                language: image.iso_639_1,
                score: image.vote_average
              }
            ] : [];
          }),
          ...data.backdrops.flatMap((image) => {
            const url = getApi().getImagePath(image.file_path);
            return url ? [
              {
                type: "backdrop",
                url,
                width: image.width,
                height: image.height,
                language: image.iso_639_1,
                score: image.vote_average
              }
            ] : [];
          })
        ];
      } catch (error) {
        logger?.error("TMDB artwork lookup failed", error, { type, externalId });
        return [];
      }
    },
    async getSeasonDetails(externalId, seasonNumber) {
      try {
        return await getDetailsSeason(getApi(), externalId, seasonNumber);
      } catch (error) {
        logger?.error("TMDB season details failed", error, { externalId, seasonNumber });
        return null;
      }
    },
    async getEpisodeDetails(externalId, seasonNumber, episodeNumber) {
      try {
        return await getDetailsEpisode(getApi(), externalId, seasonNumber, episodeNumber);
      } catch (error) {
        logger?.error("TMDB episode details failed", error, { externalId, seasonNumber, episodeNumber });
        return null;
      }
    },
    async discover(request) {
      try {
        return await discoverTmdb(getApi(), request);
      } catch (error) {
        logger?.error("TMDB discovery failed", error, { type: request.type, category: request.category });
        return { items: [], page: request.page ?? 1, totalPages: 0, totalResults: 0 };
      }
    },
    async getGenres(type) {
      try {
        return await getTmdbGenres(getApi(), type);
      } catch (error) {
        logger?.error("TMDB genres lookup failed", error, { type });
        return [];
      }
    },
    test() {
      logger?.warn("TMDB test not implemented");
      return Promise.resolve(true);
    },
    dispose() {
      api = undefined;
      logger = undefined;
    }
  };
  return provider;
}

// plugins/tmdb/index.ts
var tmdb_default = definePlugin(config, {
  async setup(host) {
    await host.providers.register(createTmdbProvider(host.config));
    host.logger.info("TMDB metadata plugin initialized");
  }
});
export {
  tmdb_default as default
};
