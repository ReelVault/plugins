// @bun
// plugins/cinemamode/index.ts
import { definePlugin, fail, ok } from "@reelvault/sdk/plugin";

// plugins/cinemamode/config.ts
import { defineConfig, field } from "@reelvault/sdk/plugin";
var config = defineConfig({
  enabled: field.boolean({
    label: "Cinema mode enabled",
    description: "Before a movie starts, the player shows a few trailers of similar titles from your library. The viewer can always skip them.",
    default: false
  }),
  tmdbApiKey: field.secret({
    label: "TMDB API key (optional)",
    description: "Your own TMDB API v3 key or Read Access Token, used to search for trailers.",
    required: false
  }),
  language: field.select({
    label: "Preferred trailer language",
    description: "Trailer language to search first (falls back to the official English trailer).",
    options: [
      { label: "English (en-US)", value: "en-US" },
      { label: "Polish (pl-PL)", value: "pl-PL" }
    ],
    default: "en-US"
  }),
  trailerCount: field.number({
    label: "Trailers before the feature",
    description: "How many trailers (1\u20135) to play before the feature.",
    default: 3,
    min: 1,
    max: 5,
    step: 1
  }),
  libraryOnly: field.boolean({
    label: "Library titles only",
    description: "Pick trailers only from titles you already own. When off, similar provider titles may appear as well.",
    default: true
  })
});

// plugins/cinemamode/src/tmdb.client.ts
function isRecord(value) {
  return typeof value === "object" && value !== null;
}
function isTmdbVideoResult(value) {
  if (!isRecord(value))
    return false;
  return typeof value.id === "string" && typeof value.iso_639_1 === "string" && typeof value.iso_3166_1 === "string" && typeof value.key === "string" && typeof value.name === "string" && typeof value.site === "string" && typeof value.size === "number" && typeof value.type === "string" && typeof value.official === "boolean" && typeof value.published_at === "string";
}
function parseVideoResults(payload) {
  if (!(isRecord(payload) && Array.isArray(payload.results)))
    return [];
  return payload.results.filter(isTmdbVideoResult);
}

class TmdbClient {
  apiKey;
  preferredLang;
  constructor(apiKey, preferredLang = "pl-PL") {
    this.apiKey = (apiKey ?? "").trim();
    this.preferredLang = preferredLang;
  }
  imageUrl(path, size = "w780") {
    if (!path)
      return;
    return `https://image.tmdb.org/t/p/${size}${path}`;
  }
  async fetchTrailer(tmdbId, mediaType) {
    const langCode = this.preferredLang.split("-")[0]?.toLowerCase() ?? "pl";
    let videos = await this.queryVideos(`/${mediaType === "movie" ? "movie" : "tv"}/${tmdbId}/videos`, langCode);
    if (mediaType === "tv_show" && videos.length === 0) {
      videos = await this.queryVideos(`/tv/${tmdbId}/season/1/videos`, langCode);
    }
    const youtubeVideos = videos.filter((v) => v.site === "YouTube" && v.key);
    if (youtubeVideos.length === 0)
      return null;
    let bestVideo = null;
    let bestScore = -1;
    for (const vid of youtubeVideos) {
      let score = 0;
      const vidLang = (vid.iso_639_1 || "").toLowerCase();
      const isPreferredLang = vidLang === langCode;
      const isEnglish = vidLang === "en" || vidLang === "";
      if (vid.type === "Trailer")
        score += 50;
      else if (vid.type === "Teaser")
        score += 20;
      else
        score += 5;
      if (vid.official)
        score += 30;
      if (isPreferredLang)
        score += 40;
      else if (isEnglish)
        score += 15;
      const nameLower = vid.name.toLowerCase();
      if (nameLower.includes("zwiastun") || nameLower.includes("trailer"))
        score += 10;
      if (nameLower.includes("official") || nameLower.includes("oficjalny"))
        score += 5;
      if (score > bestScore) {
        bestScore = score;
        bestVideo = vid;
      }
    }
    if (!bestVideo)
      return null;
    return { key: bestVideo.key, name: bestVideo.name };
  }
  async queryVideos(endpoint, langCode) {
    if (!this.apiKey)
      return [];
    try {
      const url = new URL(`https://api.themoviedb.org/3${endpoint}`);
      url.searchParams.set("include_video_language", `${langCode},en,null`);
      if (!this.apiKey.startsWith("ey")) {
        url.searchParams.set("api_key", this.apiKey);
      }
      const res = await fetch(url, {
        headers: this.apiKey.startsWith("ey") ? { Authorization: `Bearer ${this.apiKey}`, Accept: "application/json" } : { Accept: "application/json" },
        signal: AbortSignal.timeout(6000)
      });
      if (!res.ok)
        return [];
      const payload = await res.json();
      return parseVideoResults(payload);
    } catch {
      return [];
    }
  }
}

// plugins/cinemamode/src/pre-roll.manager.ts
var CACHE_PREFIX = "pre_roll_";
var CACHE_TTL_MS = 12 * 60 * 60 * 1000;
var DISCOVERY_PAGES = 2;
function isRecord2(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isPreRollCacheEntry(value) {
  return isRecord2(value) && typeof value.cachedAt === "string" && Array.isArray(value.entries);
}
function shuffle(items) {
  const copy = [...items];
  for (let i = copy.length - 1;i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const current = copy[i];
    const swap = copy[j];
    if (current === undefined || swap === undefined)
      continue;
    copy[i] = swap;
    copy[j] = current;
  }
  return copy;
}

class PreRollManager {
  host;
  config;
  tmdb;
  constructor(host, config) {
    this.host = host;
    this.config = config;
    this.tmdb = new TmdbClient(config.tmdbApiKey, config.language);
  }
  async getPreRoll(mediaFileId) {
    if (!this.config.enabled)
      return { entries: [] };
    const cached = await this.readCache(mediaFileId);
    if (cached)
      return { entries: cached };
    const source = await this.resolveSource(mediaFileId);
    if (!source)
      return { entries: [] };
    const cacheKey = `${CACHE_PREFIX}${mediaFileId}`;
    const entries = await this.buildEntries(source);
    await this.host.storage.set(cacheKey, { cachedAt: new Date().toISOString(), entries });
    return { entries };
  }
  async readCache(mediaFileId) {
    try {
      const stored = await this.host.storage.get(`${CACHE_PREFIX}${mediaFileId}`);
      if (!isPreRollCacheEntry(stored))
        return null;
      const age = Date.now() - new Date(stored.cachedAt).getTime();
      if (Number.isNaN(age) || age > CACHE_TTL_MS)
        return null;
      return stored.entries;
    } catch (error) {
      this.host.logger.warn("Pre-roll cache read failed \u2014 rebuilding", {
        mediaFileId,
        error: error instanceof Error ? error.message : String(error)
      });
      return null;
    }
  }
  async resolveSource(mediaFileId) {
    const media = await this.host.media.get(mediaFileId);
    if (!media)
      return null;
    const metadata = await this.host.metadata.get(media.metadataId);
    if (!metadata)
      return null;
    const tmdb = metadata.externalIds.find((id) => id.providerId === "tmdb");
    if (!tmdb)
      return null;
    return {
      type: metadata.type === "tv_show" ? "tv_show" : "movie",
      tmdbId: tmdb.externalId,
      tmdbExternalId: tmdb.externalId,
      title: metadata.title
    };
  }
  async buildEntries(source) {
    const candidates = await this.collectCandidates(source);
    if (candidates.length === 0)
      return [];
    const picked = shuffle(candidates).slice(0, this.config.trailerCount);
    const entries = [];
    for (const candidate of picked) {
      const trailer = await this.tmdb.fetchTrailer(Number(candidate.externalId), source.type);
      if (!trailer)
        continue;
      entries.push({
        kind: "youtube",
        key: trailer.key,
        title: candidate.title,
        trailerName: trailer.name,
        imageUrl: candidate.imageUrl,
        metadataId: candidate.metadataId
      });
    }
    return entries;
  }
  async collectCandidates(source) {
    const merged = new Map;
    for (const category of ["recommendations", "similar"]) {
      for (let page = 1;page <= DISCOVERY_PAGES; page++) {
        try {
          const result = await this.host.providers.discover({
            type: source.type,
            category,
            externalId: source.tmdbExternalId,
            providerId: "tmdb",
            page
          });
          if (!result)
            break;
          for (const item of result.items)
            this.addCandidate(merged, item, source);
          if (page >= result.totalPages)
            break;
        } catch (error) {
          this.host.logger.warn("Provider discovery failed for pre-roll", {
            category,
            page,
            error: error instanceof Error ? error.message : String(error)
          });
          break;
        }
      }
    }
    const candidates = [...merged.values()];
    if (candidates.length === 0)
      return [];
    const byExternalId = new Map(candidates.map((candidate) => [candidate.externalId, candidate]));
    let availability = [];
    try {
      availability = await this.host.metadata.findManyByExternalIds("tmdb", [...byExternalId.keys()], source.type);
    } catch (error) {
      this.host.logger.warn("Library lookup failed for pre-roll", {
        error: error instanceof Error ? error.message : String(error)
      });
    }
    const owned = [];
    for (const hit of availability) {
      const candidate = byExternalId.get(hit.externalId);
      if (candidate && hit.hasFiles)
        owned.push({ ...candidate, metadataId: hit.metadataId });
    }
    if (this.config.libraryOnly)
      return owned;
    const ownedIds = new Set(owned.map((candidate) => candidate.metadataId));
    const others = candidates.filter((candidate) => !ownedIds.has(candidate.externalId)).map((candidate) => ({ ...candidate, metadataId: undefined }));
    return [...owned, ...others];
  }
  addCandidate(target, item, source) {
    if (!item.externalId || item.externalId === source.tmdbId)
      return;
    if (target.has(item.externalId))
      return;
    target.set(item.externalId, {
      externalId: item.externalId,
      title: item.title,
      imageUrl: this.tmdb.imageUrl(item.backdropPath) ?? this.tmdb.imageUrl(item.posterPath, "w342")
    });
  }
}

// plugins/cinemamode/index.ts
var cinemamode_default = definePlugin(config, {
  async setup(host) {
    const manager = new PreRollManager(host, host.config);
    host.logger.info("Cinemamode plugin initialized", {
      enabled: host.config.enabled,
      trailerCount: host.config.trailerCount,
      libraryOnly: host.config.libraryOnly
    });
    await host.routes.register({
      method: "GET",
      path: "/pre-roll",
      handler: async ({ query }) => {
        const mediaFileId = typeof query.mediaFileId === "string" ? query.mediaFileId : "";
        if (!mediaFileId)
          return fail(400, "invalid_request", { field: "mediaFileId" });
        const result = await manager.getPreRoll(mediaFileId);
        return ok(result);
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/preview",
      access: "admin",
      handler: async ({ query }) => {
        const mediaFileId = typeof query.mediaFileId === "string" ? query.mediaFileId : "";
        if (!mediaFileId)
          return fail(400, "invalid_request", { field: "mediaFileId" });
        const result = await manager.getPreRoll(mediaFileId);
        return ok({
          ...result,
          config: { enabled: host.config.enabled, trailerCount: host.config.trailerCount, libraryOnly: host.config.libraryOnly }
        });
      }
    });
  }
});
export {
  cinemamode_default as default
};
