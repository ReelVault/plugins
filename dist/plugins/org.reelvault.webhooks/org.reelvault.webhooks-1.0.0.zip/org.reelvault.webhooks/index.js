// @bun
// plugins/webhooks/index.ts
import { definePlugin, ok } from "@reelvault/sdk/plugin";

// plugins/webhooks/config.ts
import { defineConfig, field } from "@reelvault/sdk/plugin";
var config = defineConfig({
  discordWebhookUrl: field.secret({
    label: "Discord webhook URL",
    description: "Discord channel webhook URL.",
    default: ""
  }),
  discordEnabled: field.boolean({ label: "Discord enabled", default: true }),
  telegramBotToken: field.secret({ label: "Telegram bot token", default: "" }),
  telegramChatId: field.string({ label: "Telegram chat ID", default: "" }),
  telegramEnabled: field.boolean({ label: "Telegram enabled", default: true }),
  genericWebhookUrl: field.secret({ label: "Generic webhook URL", default: "" }),
  genericEnabled: field.boolean({ label: "Generic webhook enabled", default: true }),
  serverPublicUrl: field.string({
    label: "Server public URL",
    description: "Server link appended to outgoing notifications.",
    default: ""
  }),
  onMediaReady: field.boolean({ label: "Notify on new media", default: true }),
  onPlaybackStarted: field.boolean({ label: "Notify on playback start", default: false }),
  onPlaybackStopped: field.boolean({ label: "Notify on playback stop", default: false })
});

// plugins/webhooks/src/webhook-manager.ts
var LOG_KEY = "delivery_log";
var MAX_LOG_ENTRIES = 100;

class WebhookManager {
  host;
  config;
  constructor(host, config) {
    this.host = host;
    this.config = config;
  }
  async getStatus() {
    const log = await this.getLog();
    const successful = log.filter((entry) => entry.success).length;
    const last = log[0];
    return {
      enabled: this.activeTargets().length > 0,
      version: "1.0.0",
      config: {
        discordConfigured: Boolean(this.config.discordWebhookUrl),
        discordEnabled: this.config.discordEnabled,
        telegramConfigured: Boolean(this.config.telegramBotToken && this.config.telegramChatId),
        telegramEnabled: this.config.telegramEnabled,
        genericConfigured: Boolean(this.config.genericWebhookUrl),
        genericEnabled: this.config.genericEnabled,
        events: {
          onMediaReady: this.config.onMediaReady,
          onPlaybackStarted: this.config.onPlaybackStarted,
          onPlaybackStopped: this.config.onPlaybackStopped
        },
        ...this.config.serverPublicUrl ? { serverPublicUrl: this.config.serverPublicUrl } : {}
      },
      statistics: {
        totalDeliveries: log.length,
        successfulDeliveries: successful,
        failedDeliveries: log.length - successful,
        ...last ? { lastDeliveryAt: last.timestamp } : {}
      }
    };
  }
  async getHistory() {
    return { history: await this.getLog() };
  }
  async clearHistory() {
    await this.host.storage.set(LOG_KEY, []);
    return { success: true, message: "Delivery history cleared." };
  }
  async sendTest() {
    const targets = this.activeTargets();
    if (targets.length === 0) {
      return { success: false, message: "No webhook targets are configured and enabled." };
    }
    const results = {};
    let succeeded = 0;
    for (const target of targets) {
      const result = await this.deliver(target, "test", "ReelVault test notification", "This is a test message from the Webhooks plugin.");
      results[target] = { success: result.success, ...result.error ? { error: result.error } : {} };
      if (result.success)
        succeeded++;
    }
    return { success: succeeded > 0, message: `Delivered to ${succeeded}/${targets.length} targets.`, results };
  }
  async notifyMediaReady(metadataId, mediaFileId) {
    let title = "New media available";
    try {
      const metadata = await this.host.metadata.get(metadataId);
      if (metadata?.title)
        title = metadata.title;
    } catch {}
    await this.broadcast("media.ready", title, `${metadataId} \xB7 ${mediaFileId}`);
  }
  async notifyPlaybackStarted(mediaFileId) {
    await this.broadcast("playback.started", "Playback started", mediaFileId);
  }
  async notifyPlaybackStopped(mediaFileId) {
    await this.broadcast("playback.stopped", "Playback stopped", mediaFileId);
  }
  async broadcast(event, title, details) {
    for (const target of this.activeTargets())
      await this.deliver(target, event, title, details);
  }
  activeTargets() {
    const targets = [];
    if (this.config.discordEnabled && this.config.discordWebhookUrl)
      targets.push("discord");
    if (this.config.telegramEnabled && this.config.telegramBotToken && this.config.telegramChatId)
      targets.push("telegram");
    if (this.config.genericEnabled && this.config.genericWebhookUrl)
      targets.push("generic");
    return targets;
  }
  async deliver(target, event, title, details) {
    const timestamp = new Date().toISOString();
    const result = await this.send(target, { event, title, details, timestamp });
    await this.appendLog({
      id: crypto.randomUUID(),
      timestamp,
      target,
      event,
      success: result.success,
      title,
      details,
      ...result.statusCode !== undefined ? { statusCode: result.statusCode } : {},
      ...result.error ? { error: result.error } : {}
    });
    return result;
  }
  async send(target, payload) {
    const text = `${payload.title}${payload.details ? `
${payload.details}` : ""}`;
    const init = {
      method: "POST",
      headers: { "content-type": "application/json" },
      signal: AbortSignal.timeout(1e4)
    };
    try {
      if (target === "telegram") {
        const url = `https://api.telegram.org/bot${this.config.telegramBotToken}/sendMessage`;
        const response = await this.host.http.fetch(url, {
          ...init,
          body: JSON.stringify({ chat_id: this.config.telegramChatId, text, disable_web_page_preview: true })
        });
        return this.toResult(response.status, await response.text());
      }
      if (target === "discord") {
        const response = await this.host.http.fetch(this.config.discordWebhookUrl, {
          ...init,
          body: JSON.stringify({ content: `**${payload.title}**${payload.details ? `
${payload.details}` : ""}` })
        });
        return this.toResult(response.status, await response.text());
      }
      const response = await this.host.http.fetch(this.config.genericWebhookUrl, {
        ...init,
        body: JSON.stringify({
          source: "reelvault",
          event: payload.event,
          title: payload.title,
          details: payload.details,
          timestamp: payload.timestamp,
          ...this.config.serverPublicUrl ? { server: this.config.serverPublicUrl } : {}
        })
      });
      return this.toResult(response.status, await response.text());
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : String(error) };
    }
  }
  toResult(status, body) {
    if (status >= 200 && status < 300)
      return { success: true, statusCode: status };
    const excerpt = body.length > 200 ? `${body.slice(0, 200)}\u2026` : body;
    return { success: false, statusCode: status, error: `HTTP ${status}${excerpt ? `: ${excerpt}` : ""}` };
  }
  async getLog() {
    const raw = await this.host.storage.get(LOG_KEY);
    if (!Array.isArray(raw))
      return [];
    return raw.filter((entry) => isDeliveryLog(entry));
  }
  async appendLog(entry) {
    await this.host.storage.update(LOG_KEY, (raw) => {
      const log = Array.isArray(raw) ? raw.filter((item) => isDeliveryLog(item)) : [];
      return [entry, ...log].slice(0, MAX_LOG_ENTRIES);
    });
  }
}
function isDeliveryLog(value) {
  if (typeof value !== "object" || value === null)
    return false;
  if (!("id" in value) || typeof value.id !== "string")
    return false;
  if (!("timestamp" in value) || typeof value.timestamp !== "string")
    return false;
  if (!("title" in value) || typeof value.title !== "string")
    return false;
  return true;
}

// plugins/webhooks/index.ts
var webhooks_default = definePlugin(config, {
  async setup(host) {
    const manager = new WebhookManager(host, host.config);
    host.logger.info("Webhooks plugin initialized", {
      onMediaReady: host.config.onMediaReady,
      onPlaybackStarted: host.config.onPlaybackStarted,
      onPlaybackStopped: host.config.onPlaybackStopped
    });
    await host.routes.register({
      method: "GET",
      path: "/status",
      access: "admin",
      handler: async () => ok(await manager.getStatus())
    });
    await host.routes.register({
      method: "GET",
      path: "/history",
      access: "admin",
      handler: async () => ok(await manager.getHistory())
    });
    await host.routes.register({
      method: "POST",
      path: "/test",
      access: "admin",
      handler: async () => ok(await manager.sendTest())
    });
    await host.routes.register({
      method: "POST",
      path: "/clear-history",
      access: "admin",
      handler: async () => ok(await manager.clearHistory())
    });
    host.events.on("media.file.ready", async (payload) => {
      if (host.config.onMediaReady)
        await manager.notifyMediaReady(payload.metadataId, payload.mediaFileId);
    });
    host.events.on("playback.lifecycle.started", async (payload) => {
      if (host.config.onPlaybackStarted)
        await manager.notifyPlaybackStarted(payload.mediaFileId);
    });
    host.events.on("playback.lifecycle.stopped", async (payload) => {
      if (host.config.onPlaybackStopped)
        await manager.notifyPlaybackStopped(payload.mediaFileId);
    });
  }
});
export {
  webhooks_default as default
};
