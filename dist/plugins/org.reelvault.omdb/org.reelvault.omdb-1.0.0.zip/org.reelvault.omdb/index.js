// @bun
// plugins/omdb/index.ts
import { definePlugin } from "@reelvault/sdk/plugin";

// plugins/omdb/config.ts
import { defineConfig, field } from "@reelvault/sdk/plugin";
var config = defineConfig({
  apiKey: field.secret({
    label: "OMDb API key",
    description: "Free key from omdbapi.com, used to fetch IMDb metadata for movies and series.",
    required: true,
    default: ""
  }),
  plot: field.select({
    label: "Plot length",
    description: "Whether to fetch the short or the full plot from OMDb.",
    options: [
      { label: "Full", value: "full" },
      { label: "Short", value: "short" }
    ],
    default: "full"
  })
});

// plugins/omdb/src/omdb.ts
var NOT_AVAILABLE = "N/A";
var BASE_URL = "https://www.omdbapi.com/";
var RATE_LIMIT_PATTERN = /limit/i;
var IMDB_ID_PATTERN = /^tt\d{5,}$/i;
var YEAR_PATTERN = /(\d{4})/;
var RELEASED_DATE_PATTERN = /^(\d{1,2})\s+([A-Za-z]{3,})\s+(\d{4})$/;
var FRACTION_RATING_PATTERN = /^([\d.]+)\s*\/\s*([\d.]+)$/;
var PERCENT_RATING_PATTERN = /^([\d.]+)\s*%$/;
var MONTH_ABBREVIATIONS = {
  jan: "01",
  feb: "02",
  mar: "03",
  apr: "04",
  may: "05",
  jun: "06",
  jul: "07",
  aug: "08",
  sep: "09",
  oct: "10",
  nov: "11",
  dec: "12"
};
function isRecord(value) {
  return typeof value === "object" && value !== null;
}
function isOmdbTitleResponse(value) {
  return isRecord(value) && typeof value.Response === "string";
}
function isOmdbSearchResponse(value) {
  return isRecord(value) && typeof value.Response === "string";
}

class OmdbApiError extends Error {
}

class OMDbApi {
  apiKey;
  plot;
  http;
  constructor(apiKey, plot, http) {
    this.apiKey = apiKey;
    this.plot = plot;
    this.http = http;
  }
  async search(query, type, year) {
    const params = { s: query, type };
    if (year)
      params.y = String(year);
    const data = await this.request(params, isOmdbSearchResponse);
    return data.Search ?? [];
  }
  async byId(imdbId, extra) {
    const params = { i: imdbId, plot: this.plot };
    if (extra)
      Object.assign(params, extra);
    const data = await this.request(params, isOmdbTitleResponse);
    if (data.Response !== "True")
      return null;
    return data;
  }
  async request(params, guard) {
    const url = new URL(BASE_URL);
    url.searchParams.set("apikey", this.apiKey);
    for (const [key, value] of Object.entries(params)) {
      url.searchParams.set(key, value);
    }
    const response = await this.http(url.toString());
    if (!response.ok) {
      throw new OmdbApiError(`OMDb request failed with status ${response.status}`);
    }
    const data = await response.json();
    if (!guard(data)) {
      throw new OmdbApiError("OMDb returned an unexpected response payload");
    }
    if (data.Response === "False" && isRateLimitError(data.Error)) {
      throw new OmdbApiError(data.Error ?? "OMDb request limit reached");
    }
    return data;
  }
}
function isRateLimitError(message) {
  return Boolean(message && RATE_LIMIT_PATTERN.test(message));
}
function isValidImdbId(value) {
  return Boolean(value && IMDB_ID_PATTERN.test(value.trim()));
}
function isAvailable(value) {
  return Boolean(value && value !== NOT_AVAILABLE);
}
function getImageUrl(poster) {
  return isAvailable(poster) ? poster : undefined;
}
function extractYear(value) {
  const match = value?.match(YEAR_PATTERN);
  return match?.[1];
}
function toReleaseDate(released, year) {
  const parsed = parseReleasedDate(released);
  return parsed ?? extractYear(year) ?? "";
}
function parseReleasedDate(released) {
  if (!isAvailable(released))
    return;
  const match = released.trim().match(RELEASED_DATE_PATTERN);
  if (!match)
    return;
  const day = match[1];
  const month = MONTH_ABBREVIATIONS[match[2]?.slice(0, 3).toLowerCase() ?? ""];
  const year = match[3];
  if (!(day && month && year))
    return;
  return `${year}-${month}-${day.padStart(2, "0")}`;
}
function parseNumber(value) {
  if (!isAvailable(value))
    return;
  const parsed = Number.parseFloat(value.replaceAll(",", "").trim());
  return Number.isFinite(parsed) ? parsed : undefined;
}
function splitList(value) {
  if (!isAvailable(value))
    return [];
  return value.split(",").map((item) => item.trim()).filter((item) => item.length > 0 && item !== NOT_AVAILABLE);
}
function slugify(value) {
  return value.normalize("NFKD").replace(/\p{Diacritic}/gu, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
function toEntityId(prefix, name) {
  return `${prefix}:${slugify(name) || "unknown"}`;
}
var RATING_SOURCES = {
  "internet movie database": { source: "imdb", label: "IMDb" },
  "rotten tomatoes": { source: "rottentomatoes", label: "Rotten Tomatoes" },
  metacritic: { source: "metacritic", label: "Metacritic" }
};
function parseRatingValue(raw) {
  const value = raw.trim();
  const fraction = value.match(FRACTION_RATING_PATTERN);
  if (fraction?.[1] && fraction[2]) {
    const parsedValue = Number.parseFloat(fraction[1]);
    const maxValue = Number.parseFloat(fraction[2]);
    if (Number.isFinite(parsedValue) && Number.isFinite(maxValue) && maxValue > 0)
      return { value: parsedValue, maxValue };
    return;
  }
  const percent = value.match(PERCENT_RATING_PATTERN);
  if (percent?.[1]) {
    const parsedValue = Number.parseFloat(percent[1]);
    return Number.isFinite(parsedValue) ? { value: parsedValue, maxValue: 100 } : undefined;
  }
  const plain = Number.parseFloat(value);
  return Number.isFinite(plain) ? { value: plain, maxValue: 10 } : undefined;
}
function buildRatings(details) {
  const ratings = [];
  const seen = new Set;
  for (const raw of details.Ratings ?? []) {
    const parsed = parseRatingValue(raw.Value);
    if (!parsed)
      continue;
    const mapped = RATING_SOURCES[raw.Source.trim().toLowerCase()] ?? {
      source: slugify(raw.Source) || "unknown",
      label: raw.Source.trim()
    };
    if (seen.has(mapped.source))
      continue;
    seen.add(mapped.source);
    ratings.push({
      source: mapped.source,
      label: mapped.label,
      value: parsed.value,
      maxValue: parsed.maxValue,
      votes: mapped.source === "imdb" ? parseNumber(details.imdbVotes) : undefined
    });
  }
  if (!seen.has("imdb")) {
    const imdbRating = parseNumber(details.imdbRating);
    if (imdbRating !== undefined) {
      ratings.push({ source: "imdb", label: "IMDb", value: imdbRating, maxValue: 10, votes: parseNumber(details.imdbVotes) });
    }
  }
  return ratings.length > 0 ? ratings : undefined;
}
function buildCast(actors) {
  return splitList(actors).map((name, index) => ({
    id: toEntityId("person", name),
    name,
    role: "Actor",
    character: "",
    order: index
  }));
}
function buildCrew(director, writer) {
  const crew = [];
  for (const name of splitList(director)) {
    crew.push({ id: toEntityId("person", name), name, job: "Director", department: "Directing" });
  }
  for (const name of splitList(writer)) {
    crew.push({ id: toEntityId("person", name), name, job: "Writer", department: "Writing" });
  }
  return crew;
}

// plugins/omdb/src/routes/details.ts
async function getDetails(api, type, externalId) {
  const details = await api.byId(externalId);
  if (!details)
    return null;
  return mapDetails(details, type, externalId);
}
function mapDetails(details, type, externalId) {
  return {
    externalId: details.imdbID ?? externalId,
    title: details.Title ?? "Unknown",
    overview: isAvailable(details.Plot) ? details.Plot : undefined,
    releaseDate: toReleaseDate(details.Released, details.Year),
    voteAverage: parseNumber(details.imdbRating),
    voteCount: parseNumber(details.imdbVotes),
    ratings: buildRatings(details),
    posterPath: getImageUrl(details.Poster),
    hasMissingTranslation: false,
    seasons: type === "tv_show" ? buildSeasons(details, externalId) : undefined,
    genres: splitList(details.Genre).map((name) => ({ id: toEntityId("genre", name), name })),
    productionCompanies: splitList(details.Production).map((name) => ({ id: toEntityId("company", name), name })),
    cast: buildCast(details.Actors),
    crew: buildCrew(details.Director, details.Writer)
  };
}
function buildSeasons(details, externalId) {
  const total = details.totalSeasons ? Number.parseInt(details.totalSeasons, 10) : Number.NaN;
  if (!Number.isInteger(total) || total <= 0)
    return;
  const id = details.imdbID ?? externalId;
  return Array.from({ length: total }, (_, index) => {
    const seasonNumber = index + 1;
    return {
      externalId: `${id}:s${seasonNumber}`,
      seasonNumber,
      name: `Season ${seasonNumber}`
    };
  });
}

// plugins/omdb/src/routes/episode.ts
async function getEpisode(api, externalId, seasonNumber, episodeNumber) {
  const data = await api.byId(externalId, { Season: String(seasonNumber), Episode: String(episodeNumber) });
  if (!data)
    return null;
  return {
    externalId: data.imdbID ?? externalId,
    seasonNumber,
    episodeNumber,
    name: data.Title ?? `Episode ${episodeNumber}`,
    overview: isAvailable(data.Plot) ? data.Plot : undefined,
    airDate: toReleaseDate(data.Released) || undefined,
    voteAverage: parseNumber(data.imdbRating),
    voteCount: parseNumber(data.imdbVotes),
    thumbnailPath: getImageUrl(data.Poster),
    cast: buildCast(data.Actors)
  };
}

// plugins/omdb/src/routes/search.ts
async function searchTitles(api, type, query, year) {
  const omdbType = type === "tv_show" ? "series" : "movie";
  let results = await api.search(query, omdbType, year);
  if (results.length === 0 && year) {
    results = await api.search(query, omdbType);
  }
  return results.map((item) => ({
    externalId: item.imdbID,
    title: item.Title,
    releaseDate: extractYear(item.Year) ?? "",
    posterPath: getImageUrl(item.Poster)
  }));
}

// plugins/omdb/src/routes/season.ts
async function getSeason(api, externalId, seasonNumber) {
  const data = await api.byId(externalId, { Season: String(seasonNumber) });
  if (!data)
    return null;
  return {
    externalId: `${data.imdbID ?? externalId}:s${seasonNumber}`,
    seasonNumber,
    name: `Season ${seasonNumber}`,
    episodes: (data.Episodes ?? []).map((episode) => mapEpisode(episode, seasonNumber))
  };
}
function mapEpisode(episode, seasonNumber) {
  const episodeNumber = Number.parseInt(episode.Episode, 10);
  return {
    externalId: episode.imdbID,
    seasonNumber,
    episodeNumber: Number.isInteger(episodeNumber) ? episodeNumber : episode.Episode,
    name: episode.Title,
    airDate: toReleaseDate(episode.Released) || undefined,
    voteAverage: parseNumber(episode.imdbRating),
    voteCount: parseNumber(episode.imdbVotes)
  };
}

// plugins/omdb/src/provider.ts
function createOmdbProvider(config) {
  let api;
  let logger;
  const getApi = () => {
    if (!api)
      throw new Error("OMDb provider has not been initialized");
    return api;
  };
  const provider = {
    id: "imdb",
    name: "IMDb",
    version: "1.0.0",
    supportedTypes: ["movie", "tv_show"],
    initialize(context) {
      logger = context.logger;
      api = new OMDbApi(config.apiKey, config.plot, context.http);
    },
    async search(type, query, year) {
      if (!query.trim())
        return [];
      try {
        return await searchTitles(getApi(), type, query, year);
      } catch (error) {
        logger?.error("OMDb search failed", error, { type, query, year });
        return [];
      }
    },
    async getDetails(type, externalId) {
      try {
        return await getDetails(getApi(), type, externalId);
      } catch (error) {
        logger?.error("OMDb metadata details failed", error, { type, externalId });
        return null;
      }
    },
    async getDetailsByExternalIds(type, identifiers) {
      const imdbId = identifiers.imdb?.trim();
      if (!isValidImdbId(imdbId))
        return null;
      try {
        return await getDetails(getApi(), type, imdbId);
      } catch (error) {
        logger?.error("OMDb external id lookup failed", error, { type, identifiers });
        return null;
      }
    },
    async getImages(type, externalId) {
      try {
        const details = await getApi().byId(externalId);
        const poster = details?.Poster;
        if (!poster || poster === "N/A")
          return [];
        return [{ type: "poster", url: poster }];
      } catch (error) {
        logger?.error("OMDb artwork lookup failed", error, { type, externalId });
        return [];
      }
    },
    async getSeasonDetails(externalId, seasonNumber) {
      try {
        return await getSeason(getApi(), externalId, seasonNumber);
      } catch (error) {
        logger?.error("OMDb season details failed", error, { externalId, seasonNumber });
        return null;
      }
    },
    async getEpisodeDetails(externalId, seasonNumber, episodeNumber) {
      try {
        return await getEpisode(getApi(), externalId, seasonNumber, episodeNumber);
      } catch (error) {
        logger?.error("OMDb episode details failed", error, { externalId, seasonNumber, episodeNumber });
        return null;
      }
    },
    async test() {
      if (!config.apiKey) {
        logger?.warn("OMDb API key is not configured");
        return false;
      }
      try {
        const details = await getApi().byId("tt0111161", { plot: "short" });
        return Boolean(details);
      } catch (error) {
        logger?.error("OMDb test failed", error);
        return false;
      }
    },
    dispose() {
      api = undefined;
      logger = undefined;
    }
  };
  return provider;
}

// plugins/omdb/index.ts
var omdb_default = definePlugin(config, {
  async setup(host) {
    await host.providers.register(createOmdbProvider(host.config));
    host.logger.info("OMDb metadata plugin initialized");
  }
});
export {
  omdb_default as default
};
