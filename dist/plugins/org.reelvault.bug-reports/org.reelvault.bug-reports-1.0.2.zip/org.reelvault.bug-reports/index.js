// @bun
// plugins/bug-reports/index.ts
import { definePlugin, fail } from "@reelvault/sdk/plugin";

// plugins/bug-reports/config.ts
import { defineConfig, field } from "@reelvault/sdk/plugin";
var config = defineConfig({
  notifyAdminsOnReport: field.boolean({
    label: { en: "Admin notifications", pl: "Powiadomienia dla administrator\xF3w" },
    description: {
      en: "Sends admins a notification for every newly submitted bug report.",
      pl: "Wysy\u0142a administratorom powiadomienie o ka\u017Cdym nowym zg\u0142oszeniu b\u0142\u0119du."
    },
    default: true
  }),
  maxActiveReportsPerUser: field.number({
    label: { en: "Active reports per user", pl: "Aktywne zg\u0142oszenia na u\u017Cytkownika" },
    description: {
      en: "Maximum number of open or in-progress reports a single user may have.",
      pl: "Maksymalna liczba otwartych lub b\u0119d\u0105cych w toku zg\u0142osze\u0144 jednego u\u017Cytkownika."
    },
    default: 20,
    min: 1,
    max: 100,
    step: 1
  }),
  retentionDays: field.number({
    label: { en: "Closed report retention (days)", pl: "Czas przechowywania zamkni\u0119tych zg\u0142osze\u0144 (dni)" },
    description: {
      en: "Days after which closed or rejected reports are deleted automatically (0 = never).",
      pl: "Liczba dni, po kt\xF3rych zamkni\u0119te lub odrzucone zg\u0142oszenia s\u0105 usuwane automatycznie (0 = nigdy)."
    },
    default: 90,
    min: 0,
    max: 365,
    step: 1
  })
});

// plugins/bug-reports/src/reports-manager.ts
var REPORT_KEY_PREFIX = "bug_report:";
var INDEX_KEY = "bug_reports_index";
var LEGACY_LIST_KEY = "bug_reports_list";
var MAX_STORED_REPORTS = 1500;
var MAX_LOG_CHARS = 16000;
var READ_BATCH_SIZE = 20;

class ReportNotFoundError extends Error {
}

class ReportPermissionError extends Error {
}

class ReportsManager {
  host;
  config;
  migration;
  writeQueue = Promise.resolve();
  constructor(host, config) {
    this.host = host;
    this.config = config;
  }
  async getAllReports() {
    return await this.readReports(await this.readIndex());
  }
  async getReportById(id) {
    await this.ensureMigrated();
    return await this.readReport(id) ?? null;
  }
  async listReports(filters) {
    let all = await this.getAllReports();
    if (filters?.userId) {
      all = all.filter((r) => r.reportedBy.userId === filters.userId);
    }
    if (filters?.status && filters.status !== "all") {
      all = all.filter((r) => r.status === filters.status);
    }
    if (filters?.category && filters.category !== "all") {
      all = all.filter((r) => r.category === filters.category);
    }
    if (filters?.severity && filters.severity !== "all") {
      all = all.filter((r) => r.severity === filters.severity);
    }
    if (filters?.search && filters.search.trim().length > 0) {
      const q = filters.search.toLowerCase().trim();
      all = all.filter((r) => r.title.toLowerCase().includes(q) || r.description.toLowerCase().includes(q) || (r.mediaTitle?.toLowerCase().includes(q) ?? false) || (r.pageUrl?.toLowerCase().includes(q) ?? false));
    }
    return all.toSorted((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  async createReport(input, user) {
    const now = new Date().toISOString();
    const newReport = {
      id: crypto.randomUUID(),
      title: input.title.trim(),
      description: (input.description ?? "").trim(),
      category: input.category ?? "general",
      severity: input.severity ?? "medium",
      status: "open",
      pageUrl: input.pageUrl,
      mediaId: input.mediaId,
      mediaTitle: input.mediaTitle,
      deviceInfo: input.deviceInfo,
      logs: input.logs?.slice(-MAX_LOG_CHARS),
      reportedBy: user,
      createdAt: now,
      updatedAt: now
    };
    await this.serialize(async () => {
      await this.ensureMigrated();
      const ids = await this.readIndex();
      if (ids.length >= MAX_STORED_REPORTS) {
        throw new Error(`Report storage is full (${MAX_STORED_REPORTS} reports). Delete closed reports first.`);
      }
      const activeReportsCount = (await this.readReports(ids)).filter((r) => r.reportedBy.userId === user.userId && (r.status === "open" || r.status === "in_progress")).length;
      if (activeReportsCount >= this.config.maxActiveReportsPerUser) {
        throw new Error(`Active report limit reached (${this.config.maxActiveReportsPerUser}). Wait for earlier reports to be resolved.`);
      }
      await this.host.storage.set(this.reportKey(newReport.id), newReport);
      await this.host.storage.update(INDEX_KEY, (current) => appendId(current, newReport.id));
    });
    if ((input.logs?.length ?? 0) > MAX_LOG_CHARS) {
      this.host.logger.info("Bug report logs were trimmed to their newest characters", { id: newReport.id, maxChars: MAX_LOG_CHARS });
    }
    this.host.logger.info("New bug report created", {
      id: newReport.id,
      category: newReport.category,
      severity: newReport.severity,
      userId: user.userId
    });
    return newReport;
  }
  async updateReport(id, input) {
    return await this.serialize(async () => {
      await this.ensureMigrated();
      const stored = await this.host.storage.update(this.reportKey(id), (current) => {
        if (!isBugReport(current)) {
          throw new ReportNotFoundError(`Report with ID "${id}" does not exist.`);
        }
        const now = new Date().toISOString();
        const updatedStatus = input.status ?? current.status;
        const isResolving = (updatedStatus === "resolved" || updatedStatus === "closed") && current.status !== "resolved" && current.status !== "closed";
        return {
          ...current,
          ...input.status ? { status: input.status } : {},
          ...input.severity ? { severity: input.severity } : {},
          ...input.adminNotes !== undefined ? { adminNotes: input.adminNotes } : {},
          ...isResolving ? { resolvedAt: now } : {},
          updatedAt: now
        };
      });
      if (!isBugReport(stored)) {
        throw new ReportNotFoundError(`Report with ID "${id}" does not exist.`);
      }
      this.host.logger.info("Bug report updated", {
        id,
        status: stored.status,
        severity: stored.severity
      });
      return stored;
    });
  }
  async deleteReport(id, userId, isAdmin) {
    await this.serialize(async () => {
      await this.ensureMigrated();
      const report = await this.readReport(id);
      if (!report) {
        throw new ReportNotFoundError(`Report with ID "${id}" was not found.`);
      }
      if (!isAdmin && report.reportedBy.userId !== userId) {
        throw new ReportPermissionError("You do not have permission to delete this report.");
      }
      await this.host.storage.delete(this.reportKey(id));
      await this.host.storage.update(INDEX_KEY, (current) => removeIds(current, [id]));
    });
    this.host.logger.info("Bug report deleted", { id, deletedBy: userId, isAdmin });
  }
  async getSummary() {
    const all = await this.getAllReports();
    const summary = {
      total: all.length,
      open: 0,
      inProgress: 0,
      resolved: 0,
      closed: 0,
      rejected: 0,
      byCategory: {
        playback: 0,
        metadata: 0,
        subtitles: 0,
        ui: 0,
        performance: 0,
        general: 0,
        other: 0
      },
      bySeverity: {
        low: 0,
        medium: 0,
        high: 0,
        critical: 0
      }
    };
    for (const r of all) {
      if (r.status === "open")
        summary.open++;
      else if (r.status === "in_progress")
        summary.inProgress++;
      else if (r.status === "resolved")
        summary.resolved++;
      else if (r.status === "closed")
        summary.closed++;
      else
        summary.rejected++;
      if (r.category in summary.byCategory) {
        const current = summary.byCategory[r.category] ?? 0;
        summary.byCategory[r.category] = current + 1;
      } else {
        summary.byCategory[r.category] = 1;
      }
      if (r.severity in summary.bySeverity) {
        const current = summary.bySeverity[r.severity] ?? 0;
        summary.bySeverity[r.severity] = current + 1;
      }
    }
    return summary;
  }
  async cleanupOldReports() {
    if (this.config.retentionDays <= 0)
      return 0;
    const cutoffTime = Date.now() - this.config.retentionDays * 24 * 60 * 60 * 1000;
    const removedIds = await this.serialize(async () => {
      await this.ensureMigrated();
      const expired = (await this.getAllReports()).filter((r) => (r.status === "closed" || r.status === "rejected" || r.status === "resolved") && new Date(r.updatedAt).getTime() < cutoffTime).map((r) => r.id);
      for (const id of expired)
        await this.host.storage.delete(this.reportKey(id));
      if (expired.length > 0)
        await this.host.storage.update(INDEX_KEY, (current) => removeIds(current, expired));
      return expired;
    });
    if (removedIds.length > 0) {
      this.host.logger.info(`Cleaned up ${removedIds.length} expired bug reports.`);
    }
    return removedIds.length;
  }
  async serialize(operation) {
    const previous = this.writeQueue;
    const finished = Promise.withResolvers();
    this.writeQueue = finished.promise;
    try {
      await previous;
      return await operation();
    } finally {
      finished.resolve();
    }
  }
  reportKey(id) {
    return `${REPORT_KEY_PREFIX}${id}`;
  }
  async readReport(id) {
    const stored = await this.host.storage.get(this.reportKey(id));
    return isBugReport(stored) ? stored : undefined;
  }
  async readReports(ids) {
    const reports = [];
    for (let start = 0;start < ids.length; start += READ_BATCH_SIZE) {
      const batch = await Promise.all(ids.slice(start, start + READ_BATCH_SIZE).map((id) => this.readReport(id)));
      for (const report of batch) {
        if (report)
          reports.push(report);
      }
    }
    return reports;
  }
  async readIndex() {
    await this.ensureMigrated();
    const stored = await this.host.storage.get(INDEX_KEY);
    return isStringArray(stored) ? stored : [];
  }
  ensureMigrated() {
    this.migration ??= this.migrateLegacyList();
    return this.migration;
  }
  async migrateLegacyList() {
    try {
      const legacy = await this.host.storage.get(LEGACY_LIST_KEY);
      if (!isBugReportArray(legacy))
        return;
      for (const report of legacy)
        await this.host.storage.set(this.reportKey(report.id), report);
      const legacyIds = legacy.map((report) => report.id);
      await this.host.storage.update(INDEX_KEY, (current) => mergeIds(current, legacyIds));
      await this.host.storage.delete(LEGACY_LIST_KEY);
    } catch (error) {
      this.migration = undefined;
      throw error;
    }
  }
}
function isBugReport(value) {
  return typeof value === "object" && value !== null && "id" in value && typeof value.id === "string";
}
function isBugReportArray(value) {
  return Array.isArray(value) && value.every((item) => isBugReport(item));
}
function isStringArray(value) {
  return Array.isArray(value) && value.every((item) => typeof item === "string");
}
function appendId(current, id) {
  const ids = isStringArray(current) ? current : [];
  return ids.includes(id) ? ids : [...ids, id];
}
function mergeIds(current, added) {
  return [...new Set([...isStringArray(current) ? current : [], ...added])];
}
function removeIds(current, removed) {
  const drop = new Set(removed);
  return (isStringArray(current) ? current : []).filter((id) => !drop.has(id));
}

// plugins/bug-reports/index.ts
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isBugReportStatus(value) {
  return value === "open" || value === "in_progress" || value === "resolved" || value === "closed" || value === "rejected";
}
function isBugReportCategory(value) {
  return value === "playback" || value === "metadata" || value === "subtitles" || value === "ui" || value === "performance" || value === "general" || value === "other";
}
function isBugReportSeverity(value) {
  return value === "low" || value === "medium" || value === "high" || value === "critical";
}
function optionalString(record, key) {
  const value = record[key];
  return typeof value === "string" && value !== "" ? value : undefined;
}
function nonEmpty(value) {
  return value === "" ? undefined : value;
}
function parseStatusFilter(value) {
  if (value === "all")
    return "all";
  return isBugReportStatus(value) ? value : undefined;
}
function parseCategoryFilter(value) {
  if (value === "all")
    return "all";
  return isBugReportCategory(value) ? value : undefined;
}
function parseSeverityFilter(value) {
  if (value === "all")
    return "all";
  return isBugReportSeverity(value) ? value : undefined;
}
function parseDeviceInfo(value) {
  if (!isRecord(value))
    return;
  const info = {};
  if (typeof value.browser === "string")
    info.browser = value.browser;
  if (typeof value.os === "string")
    info.os = value.os;
  if (typeof value.screenResolution === "string")
    info.screenResolution = value.screenResolution;
  if (typeof value.language === "string")
    info.language = value.language;
  if (typeof value.userAgent === "string")
    info.userAgent = value.userAgent;
  return info;
}
function parseCreateBugReportInput(body) {
  if (!isRecord(body))
    return null;
  const title = typeof body.title === "string" ? body.title.trim() : "";
  if (!title)
    return null;
  const description = optionalString(body, "description");
  const category = isBugReportCategory(body.category) ? body.category : undefined;
  const severity = isBugReportSeverity(body.severity) ? body.severity : undefined;
  const pageUrl = optionalString(body, "pageUrl");
  const mediaId = optionalString(body, "mediaId");
  const mediaTitle = optionalString(body, "mediaTitle");
  const logs = optionalString(body, "logs");
  const deviceInfo = parseDeviceInfo(body.deviceInfo);
  return {
    title,
    ...description !== undefined ? { description } : {},
    ...category !== undefined ? { category } : {},
    ...severity !== undefined ? { severity } : {},
    ...pageUrl !== undefined ? { pageUrl } : {},
    ...mediaId !== undefined ? { mediaId } : {},
    ...mediaTitle !== undefined ? { mediaTitle } : {},
    ...logs !== undefined ? { logs } : {},
    ...deviceInfo !== undefined ? { deviceInfo } : {}
  };
}
function parseUpdateBugReportInput(body) {
  if (!isRecord(body))
    return null;
  const update = {};
  if (isBugReportStatus(body.status))
    update.status = body.status;
  if (isBugReportSeverity(body.severity))
    update.severity = body.severity;
  if (typeof body.adminNotes === "string")
    update.adminNotes = body.adminNotes;
  return update;
}
var bug_reports_default = definePlugin(config, {
  async setup(host) {
    const manager = new ReportsManager(host, host.config);
    host.logger.info("Bug Reports plugin initialized", {
      notifyAdminsOnReport: host.config.notifyAdminsOnReport,
      maxActiveReportsPerUser: host.config.maxActiveReportsPerUser,
      retentionDays: host.config.retentionDays
    });
    await host.tasks.register({
      id: "bug-reports-cleanup",
      name: "bug-reports-cleanup",
      description: "Deletes expired, closed and rejected bug reports according to the retention window.",
      defaultTriggers: [{ id: "bug-reports-cleanup-daily", type: "interval", intervalMinutes: 1440 }],
      run: async () => {
        const cleaned = await manager.cleanupOldReports();
        host.logger.info("Bug reports cleanup completed", { cleaned });
        return cleaned > 0 ? `Cleaned ${cleaned} bug reports` : "No bug reports needed cleanup";
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/reports",
      handler: async ({ query, user }) => {
        const status = parseStatusFilter(query.status);
        const category = parseCategoryFilter(query.category);
        const severity = parseSeverityFilter(query.severity);
        const search = nonEmpty(query.search);
        const isUserScope = query.scope !== "all" || user.role !== "admin";
        const userId = isUserScope ? user.id : undefined;
        const reports = await manager.listReports({
          userId,
          status,
          category,
          severity,
          search
        });
        return {
          body: {
            reports,
            total: reports.length
          }
        };
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/reports/summary",
      access: "admin",
      handler: async () => {
        const summary = await manager.getSummary();
        return {
          body: summary
        };
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/reports/item/:id",
      handler: async ({ params, user }) => {
        const id = params.id;
        if (!id) {
          return fail(400, "bug_reports.id_required");
        }
        const report = await manager.getReportById(id);
        if (!report) {
          return fail(404, "bug_reports.not_found");
        }
        const isAdmin = user.role === "admin";
        if (!isAdmin && report.reportedBy.userId !== user.id) {
          return fail(403, "bug_reports.forbidden");
        }
        return {
          body: {
            report
          }
        };
      }
    });
    await host.routes.register({
      method: "POST",
      path: "/reports",
      handler: async ({ body, user }) => {
        const input = parseCreateBugReportInput(body);
        if (!input) {
          return {
            body: { error: "The 'title' field is required." }
          };
        }
        const userId = user.id;
        const profileId = user.profileId;
        const userRole = user.role;
        try {
          const report = await manager.createReport(input, {
            userId,
            profileId,
            role: userRole
          });
          if (host.config.notifyAdminsOnReport) {
            try {
              await host.notifications.createForAdmins({
                type: "bug-report",
                title: `New bug report: ${report.title}`,
                message: `Kategoria: ${report.category}, Priorytet: ${report.severity}`,
                data: { reportId: report.id }
              });
            } catch {
              host.logger.warn("Could not dispatch notification for bug report", { reportId: report.id });
            }
          }
          return {
            status: 201,
            body: {
              success: true,
              report
            }
          };
        } catch (err) {
          return {
            body: { error: err instanceof Error ? err.message : "Failed to create the report." }
          };
        }
      }
    });
    await host.routes.register({
      method: "PATCH",
      path: "/reports/:id",
      access: "admin",
      handler: async ({ params, body }) => {
        const id = params.id;
        const payload = parseUpdateBugReportInput(body);
        if (!id) {
          return fail(400, "bug_reports.id_required");
        }
        if (!payload) {
          return fail(400, "bug_reports.invalid_update");
        }
        try {
          const updated = await manager.updateReport(id, payload);
          return {
            body: {
              success: true,
              report: updated
            }
          };
        } catch (err) {
          if (err instanceof ReportNotFoundError)
            return fail(404, "bug_reports.not_found");
          throw err;
        }
      }
    });
    await host.routes.register({
      method: "DELETE",
      path: "/reports/:id",
      handler: async ({ params, user }) => {
        const id = params.id;
        if (!id) {
          return fail(400, "bug_reports.id_required");
        }
        const isAdmin = user.role === "admin";
        const userId = user.id;
        try {
          await manager.deleteReport(id, userId, isAdmin);
          return {
            body: {
              success: true,
              message: "The report was deleted."
            }
          };
        } catch (err) {
          if (err instanceof ReportNotFoundError)
            return fail(404, "bug_reports.not_found");
          if (err instanceof ReportPermissionError)
            return fail(403, "bug_reports.forbidden");
          throw err;
        }
      }
    });
  }
});
export {
  bug_reports_default as default
};
