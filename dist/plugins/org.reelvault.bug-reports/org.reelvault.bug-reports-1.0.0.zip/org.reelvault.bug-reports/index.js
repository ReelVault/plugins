// @bun
// plugins/bug-reports/index.ts
import { definePlugin } from "@reelvault/sdk/plugin";

// plugins/bug-reports/config.ts
import { defineConfig, field } from "@reelvault/sdk/plugin";
var config = defineConfig({
  notifyAdminsOnReport: field.boolean({
    label: "Admin notifications",
    description: "Sends the admin a notification for every newly submitted bug report.",
    default: true
  }),
  maxActiveReportsPerUser: field.number({
    label: "Active reports per user",
    description: "Maximum number of open or in-progress reports a single user may have.",
    default: 20,
    min: 1,
    max: 100,
    step: 1
  }),
  retentionDays: field.number({
    label: "Closed report retention (days)",
    description: "Days after which closed or rejected reports are deleted automatically (0 = never).",
    default: 90,
    min: 0,
    max: 365,
    step: 1
  })
});

// plugins/bug-reports/src/reports-manager.ts
var STORAGE_KEY_REPORTS = "bug_reports_list";

class ReportsManager {
  host;
  config;
  constructor(host, config) {
    this.host = host;
    this.config = config;
  }
  async getAllReports() {
    const stored = await this.host.storage.get(STORAGE_KEY_REPORTS);
    return isBugReportArray(stored) ? stored : [];
  }
  async getReportById(id) {
    const all = await this.getAllReports();
    return all.find((r) => r.id === id) ?? null;
  }
  async listReports(filters) {
    let all = await this.getAllReports();
    if (filters?.userId) {
      all = all.filter((r) => r.reportedBy.userId === filters.userId);
    }
    if (filters?.status && filters.status !== "all") {
      all = all.filter((r) => r.status === filters.status);
    }
    if (filters?.category && filters.category !== "all") {
      all = all.filter((r) => r.category === filters.category);
    }
    if (filters?.severity && filters.severity !== "all") {
      all = all.filter((r) => r.severity === filters.severity);
    }
    if (filters?.search && filters.search.trim().length > 0) {
      const q = filters.search.toLowerCase().trim();
      all = all.filter((r) => r.title.toLowerCase().includes(q) || r.description.toLowerCase().includes(q) || (r.mediaTitle?.toLowerCase().includes(q) ?? false) || (r.pageUrl?.toLowerCase().includes(q) ?? false));
    }
    return all.toSorted((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  async createReport(input, user) {
    const all = await this.getAllReports();
    const activeReportsCount = all.filter((r) => r.reportedBy.userId === user.userId && (r.status === "open" || r.status === "in_progress")).length;
    if (activeReportsCount >= this.config.maxActiveReportsPerUser) {
      throw new Error(`Active report limit reached (${this.config.maxActiveReportsPerUser}). Wait for earlier reports to be resolved.`);
    }
    const now = new Date().toISOString();
    const newReport = {
      id: crypto.randomUUID(),
      title: input.title.trim(),
      description: (input.description ?? "").trim(),
      category: input.category ?? "general",
      severity: input.severity ?? "medium",
      status: "open",
      pageUrl: input.pageUrl,
      mediaId: input.mediaId,
      mediaTitle: input.mediaTitle,
      deviceInfo: input.deviceInfo,
      logs: input.logs,
      reportedBy: user,
      createdAt: now,
      updatedAt: now
    };
    all.push(newReport);
    await this.host.storage.set(STORAGE_KEY_REPORTS, all);
    this.host.logger.info("New bug report created", {
      id: newReport.id,
      category: newReport.category,
      severity: newReport.severity,
      userId: user.userId
    });
    return newReport;
  }
  async updateReport(id, input) {
    const all = await this.getAllReports();
    const reportIndex = all.findIndex((r) => r.id === id);
    if (reportIndex === -1) {
      throw new Error(`Report with ID "${id}" does not exist.`);
    }
    const existing = all[reportIndex];
    if (!existing) {
      throw new Error(`Report with ID "${id}" does not exist.`);
    }
    const now = new Date().toISOString();
    const updatedStatus = input.status ?? existing.status;
    const isResolving = (updatedStatus === "resolved" || updatedStatus === "closed") && existing.status !== "resolved" && existing.status !== "closed";
    const updatedReport = {
      ...existing,
      ...input.status ? { status: input.status } : {},
      ...input.severity ? { severity: input.severity } : {},
      ...input.adminNotes !== undefined ? { adminNotes: input.adminNotes } : {},
      ...isResolving ? { resolvedAt: now } : {},
      updatedAt: now
    };
    all[reportIndex] = updatedReport;
    await this.host.storage.set(STORAGE_KEY_REPORTS, all);
    this.host.logger.info("Bug report updated", {
      id,
      status: updatedReport.status,
      severity: updatedReport.severity
    });
    return updatedReport;
  }
  async deleteReport(id, userId, isAdmin) {
    const all = await this.getAllReports();
    const report = all.find((r) => r.id === id);
    if (!report) {
      throw new Error(`Report with ID "${id}" was not found.`);
    }
    if (!isAdmin && report.reportedBy.userId !== userId) {
      throw new Error("You do not have permission to delete this report.");
    }
    const filtered = all.filter((r) => r.id !== id);
    await this.host.storage.set(STORAGE_KEY_REPORTS, filtered);
    this.host.logger.info("Bug report deleted", { id, deletedBy: userId, isAdmin });
  }
  async getSummary() {
    const all = await this.getAllReports();
    const summary = {
      total: all.length,
      open: 0,
      inProgress: 0,
      resolved: 0,
      closed: 0,
      rejected: 0,
      byCategory: {
        playback: 0,
        metadata: 0,
        subtitles: 0,
        ui: 0,
        performance: 0,
        general: 0,
        other: 0
      },
      bySeverity: {
        low: 0,
        medium: 0,
        high: 0,
        critical: 0
      }
    };
    for (const r of all) {
      if (r.status === "open")
        summary.open++;
      else if (r.status === "in_progress")
        summary.inProgress++;
      else if (r.status === "resolved")
        summary.resolved++;
      else if (r.status === "closed")
        summary.closed++;
      else
        summary.rejected++;
      if (r.category in summary.byCategory) {
        const current = summary.byCategory[r.category] ?? 0;
        summary.byCategory[r.category] = current + 1;
      } else {
        summary.byCategory[r.category] = 1;
      }
      if (r.severity in summary.bySeverity) {
        const current = summary.bySeverity[r.severity] ?? 0;
        summary.bySeverity[r.severity] = current + 1;
      }
    }
    return summary;
  }
  async cleanupOldReports() {
    if (this.config.retentionDays <= 0)
      return 0;
    const all = await this.getAllReports();
    const cutoffTime = Date.now() - this.config.retentionDays * 24 * 60 * 60 * 1000;
    const toKeep = all.filter((r) => {
      if (r.status !== "closed" && r.status !== "rejected" && r.status !== "resolved") {
        return true;
      }
      const reportTime = new Date(r.updatedAt).getTime();
      return reportTime >= cutoffTime;
    });
    const removedCount = all.length - toKeep.length;
    if (removedCount > 0) {
      await this.host.storage.set(STORAGE_KEY_REPORTS, toKeep);
      this.host.logger.info(`Cleaned up ${removedCount} expired bug reports.`);
    }
    return removedCount;
  }
}
function isBugReportArray(value) {
  return Array.isArray(value);
}

// plugins/bug-reports/index.ts
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isBugReportStatus(value) {
  return value === "open" || value === "in_progress" || value === "resolved" || value === "closed" || value === "rejected";
}
function isBugReportCategory(value) {
  return value === "playback" || value === "metadata" || value === "subtitles" || value === "ui" || value === "performance" || value === "general" || value === "other";
}
function isBugReportSeverity(value) {
  return value === "low" || value === "medium" || value === "high" || value === "critical";
}
function optionalString(record, key) {
  const value = record[key];
  return typeof value === "string" && value !== "" ? value : undefined;
}
function nonEmpty(value) {
  return value === "" ? undefined : value;
}
function parseStatusFilter(value) {
  if (value === "all")
    return "all";
  return isBugReportStatus(value) ? value : undefined;
}
function parseCategoryFilter(value) {
  if (value === "all")
    return "all";
  return isBugReportCategory(value) ? value : undefined;
}
function parseSeverityFilter(value) {
  if (value === "all")
    return "all";
  return isBugReportSeverity(value) ? value : undefined;
}
function parseDeviceInfo(value) {
  if (!isRecord(value))
    return;
  const info = {};
  if (typeof value.browser === "string")
    info.browser = value.browser;
  if (typeof value.os === "string")
    info.os = value.os;
  if (typeof value.screenResolution === "string")
    info.screenResolution = value.screenResolution;
  if (typeof value.language === "string")
    info.language = value.language;
  if (typeof value.userAgent === "string")
    info.userAgent = value.userAgent;
  return info;
}
function parseCreateBugReportInput(body) {
  if (!isRecord(body))
    return null;
  const title = typeof body.title === "string" ? body.title.trim() : "";
  if (!title)
    return null;
  const description = optionalString(body, "description");
  const category = isBugReportCategory(body.category) ? body.category : undefined;
  const severity = isBugReportSeverity(body.severity) ? body.severity : undefined;
  const pageUrl = optionalString(body, "pageUrl");
  const mediaId = optionalString(body, "mediaId");
  const mediaTitle = optionalString(body, "mediaTitle");
  const logs = optionalString(body, "logs");
  const deviceInfo = parseDeviceInfo(body.deviceInfo);
  return {
    title,
    ...description !== undefined ? { description } : {},
    ...category !== undefined ? { category } : {},
    ...severity !== undefined ? { severity } : {},
    ...pageUrl !== undefined ? { pageUrl } : {},
    ...mediaId !== undefined ? { mediaId } : {},
    ...mediaTitle !== undefined ? { mediaTitle } : {},
    ...logs !== undefined ? { logs } : {},
    ...deviceInfo !== undefined ? { deviceInfo } : {}
  };
}
function parseUpdateBugReportInput(body) {
  if (!isRecord(body))
    return null;
  const update = {};
  if (isBugReportStatus(body.status))
    update.status = body.status;
  if (isBugReportSeverity(body.severity))
    update.severity = body.severity;
  if (typeof body.adminNotes === "string")
    update.adminNotes = body.adminNotes;
  return update;
}
var bug_reports_default = definePlugin(config, {
  async setup(host) {
    const manager = new ReportsManager(host, host.config);
    host.logger.info("Bug Reports plugin initialized", {
      notifyAdminsOnReport: host.config.notifyAdminsOnReport,
      maxActiveReportsPerUser: host.config.maxActiveReportsPerUser,
      retentionDays: host.config.retentionDays
    });
    await host.tasks.register({
      id: "bug-reports-cleanup",
      name: "bug-reports-cleanup",
      description: "Deletes expired, closed and rejected bug reports according to the retention window.",
      defaultTriggers: [{ id: "bug-reports-cleanup-daily", type: "interval", intervalMinutes: 1440 }],
      run: async () => {
        const cleaned = await manager.cleanupOldReports();
        host.logger.info("Bug reports cleanup completed", { cleaned });
        return cleaned > 0 ? `Cleaned ${cleaned} bug reports` : "No bug reports needed cleanup";
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/reports",
      handler: async ({ query, user }) => {
        const status = parseStatusFilter(query.status);
        const category = parseCategoryFilter(query.category);
        const severity = parseSeverityFilter(query.severity);
        const search = nonEmpty(query.search);
        const isUserScope = query.scope !== "all" || user.role !== "admin";
        const userId = isUserScope ? user.id : undefined;
        const reports = await manager.listReports({
          userId,
          status,
          category,
          severity,
          search
        });
        return {
          body: {
            reports,
            total: reports.length
          }
        };
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/reports/summary",
      handler: async () => {
        const summary = await manager.getSummary();
        return {
          body: summary
        };
      }
    });
    await host.routes.register({
      method: "GET",
      path: "/reports/item/:id",
      handler: async ({ params, user }) => {
        const id = params.id;
        if (!id) {
          return { body: { error: "Missing report ID." } };
        }
        const report = await manager.getReportById(id);
        if (!report) {
          return { body: { error: "Report does not exist." } };
        }
        const isAdmin = user.role === "admin";
        if (!isAdmin && report.reportedBy.userId !== user.id) {
          return { body: { error: "You do not have access to this report." } };
        }
        return {
          body: {
            report
          }
        };
      }
    });
    await host.routes.register({
      method: "POST",
      path: "/reports",
      handler: async ({ body, user }) => {
        const input = parseCreateBugReportInput(body);
        if (!input) {
          return {
            body: { error: "The 'title' field is required." }
          };
        }
        const userId = user.id;
        const profileId = user.profileId;
        const userRole = user.role;
        try {
          const report = await manager.createReport(input, {
            userId,
            profileId,
            role: userRole
          });
          if (host.config.notifyAdminsOnReport) {
            try {
              await host.notifications.create({
                userId,
                profileId,
                type: "bug-report",
                title: `New bug report: ${report.title}`,
                message: `Kategoria: ${report.category}, Priorytet: ${report.severity}`,
                data: { reportId: report.id }
              });
            } catch {
              host.logger.warn("Could not dispatch notification for bug report", { reportId: report.id });
            }
          }
          return {
            status: 201,
            body: {
              success: true,
              report
            }
          };
        } catch (err) {
          return {
            body: { error: err instanceof Error ? err.message : "Failed to create the report." }
          };
        }
      }
    });
    await host.routes.register({
      method: "PATCH",
      path: "/reports/:id",
      access: "admin",
      handler: async ({ params, body }) => {
        const id = params.id;
        const payload = parseUpdateBugReportInput(body);
        if (!id) {
          return { body: { error: "Missing report ID." } };
        }
        if (!payload) {
          return { body: { error: "Invalid report update data." } };
        }
        try {
          const updated = await manager.updateReport(id, payload);
          return {
            body: {
              success: true,
              report: updated
            }
          };
        } catch (err) {
          return {
            body: { error: err instanceof Error ? err.message : "Failed to update the report." }
          };
        }
      }
    });
    await host.routes.register({
      method: "DELETE",
      path: "/reports/:id",
      handler: async ({ params, user }) => {
        const id = params.id;
        if (!id) {
          return { body: { error: "Missing report ID." } };
        }
        const isAdmin = user.role === "admin";
        const userId = user.id;
        try {
          await manager.deleteReport(id, userId, isAdmin);
          return {
            body: {
              success: true,
              message: "The report was deleted."
            }
          };
        } catch (err) {
          return {
            body: { error: err instanceof Error ? err.message : "Failed to delete the report." }
          };
        }
      }
    });
  }
});
export {
  bug_reports_default as default
};
