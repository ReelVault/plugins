// @bun
// plugins/trailers/index.ts
import { definePlugin, ok, route, t } from "@reelvault/sdk/plugin";

// plugins/trailers/config.ts
import { defineConfig, field } from "@reelvault/sdk/plugin";
var config = defineConfig({
  apiKey: field.secret({
    label: "TMDB API key (optional)",
    description: "Your own TMDB API v3 key or Read Access Token, used to search for trailers.",
    required: false
  }),
  preferredLanguage: field.select({
    label: "Preferred trailer language",
    description: "Trailer language to search first (falls back to the official English trailer).",
    options: [
      { label: "English (en-US)", value: "en-US" },
      { label: "Polish (pl-PL)", value: "pl-PL" }
    ],
    default: "en-US"
  })
});

// plugins/trailers/src/tmdb-trailers.client.ts
function isRecord(value) {
  return typeof value === "object" && value !== null;
}
function isTmdbVideoResult(value) {
  if (!isRecord(value))
    return false;
  return typeof value.id === "string" && typeof value.iso_639_1 === "string" && typeof value.iso_3166_1 === "string" && typeof value.key === "string" && typeof value.name === "string" && typeof value.site === "string" && typeof value.size === "number" && typeof value.type === "string" && typeof value.official === "boolean" && typeof value.published_at === "string";
}
function parseSearchFirstId(payload) {
  if (!(isRecord(payload) && Array.isArray(payload.results)))
    return;
  const first = payload.results[0];
  if (!isRecord(first) || typeof first.id !== "number")
    return;
  return first.id;
}
function parseVideoResults(payload) {
  if (!(isRecord(payload) && Array.isArray(payload.results)))
    return [];
  return payload.results.filter(isTmdbVideoResult);
}

class TmdbTrailersClient {
  apiKey;
  preferredLang;
  constructor(apiKey, preferredLang = "pl-PL") {
    this.apiKey = (apiKey ?? "").trim();
    this.preferredLang = preferredLang;
  }
  getHeaders() {
    if (this.apiKey.startsWith("ey")) {
      return {
        Authorization: `Bearer ${this.apiKey}`,
        Accept: "application/json"
      };
    }
    return {
      Accept: "application/json"
    };
  }
  getUrl(endpoint, queryParams = {}) {
    const url = new URL(`https://api.themoviedb.org/3${endpoint}`);
    if (!this.apiKey.startsWith("ey")) {
      url.searchParams.set("api_key", this.apiKey);
    }
    for (const [k, v] of Object.entries(queryParams)) {
      url.searchParams.set(k, v);
    }
    return url.toString();
  }
  async searchTmdbId(title, mediaType, year) {
    if (!this.apiKey)
      return null;
    const primaryEndpoint = mediaType === "movie" ? "/search/movie" : "/search/tv";
    const secondaryEndpoint = mediaType === "movie" ? "/search/tv" : "/search/movie";
    const primaryParams = {
      query: title,
      include_adult: "false",
      language: this.preferredLang
    };
    if (year) {
      if (mediaType === "movie")
        primaryParams.year = String(year);
      else
        primaryParams.first_air_date_year = String(year);
    }
    try {
      const res = await fetch(this.getUrl(primaryEndpoint, primaryParams), {
        headers: this.getHeaders(),
        signal: AbortSignal.timeout(6000)
      });
      if (res.ok) {
        const payload = await res.json();
        const id = parseSearchFirstId(payload);
        if (id) {
          return { id, mediaType };
        }
      }
      const secParams = {
        query: title,
        include_adult: "false",
        language: this.preferredLang
      };
      const fallbackType = mediaType === "movie" ? "tv_show" : "movie";
      const secRes = await fetch(this.getUrl(secondaryEndpoint, secParams), {
        headers: this.getHeaders(),
        signal: AbortSignal.timeout(6000)
      });
      if (secRes.ok) {
        const payload = await secRes.json();
        const id = parseSearchFirstId(payload);
        if (id) {
          return { id, mediaType: fallbackType };
        }
      }
    } catch {
      return null;
    }
    return null;
  }
  async fetchTrailer(tmdbId, mediaType) {
    const langCode = this.preferredLang.split("-")[0]?.toLowerCase() ?? "pl";
    let videos = await this.queryVideos(`/${mediaType === "movie" ? "movie" : "tv"}/${tmdbId}/videos`, langCode);
    if (mediaType === "tv_show" && videos.length === 0) {
      videos = await this.queryVideos(`/tv/${tmdbId}/season/1/videos`, langCode);
    }
    const youtubeVideos = videos.filter((v) => v.site === "YouTube" && v.key);
    if (youtubeVideos.length === 0)
      return null;
    let bestVideo = null;
    let bestScore = -1;
    for (const vid of youtubeVideos) {
      let score = 0;
      const vidLang = (vid.iso_639_1 || "").toLowerCase();
      const isPreferredLang = vidLang === langCode;
      const isEnglish = vidLang === "en" || vidLang === "";
      if (vid.type === "Trailer")
        score += 50;
      else if (vid.type === "Teaser")
        score += 20;
      else
        score += 5;
      if (vid.official)
        score += 30;
      if (isPreferredLang)
        score += 40;
      else if (isEnglish)
        score += 15;
      const nameLower = vid.name.toLowerCase();
      if (nameLower.includes("zwiastun") || nameLower.includes("trailer")) {
        score += 10;
      }
      if (nameLower.includes("official") || nameLower.includes("oficjalny")) {
        score += 5;
      }
      if (score > bestScore) {
        bestScore = score;
        bestVideo = vid;
      }
    }
    if (!bestVideo)
      return null;
    return {
      key: bestVideo.key,
      name: bestVideo.name,
      official: bestVideo.official,
      language: bestVideo.iso_639_1,
      site: "YouTube"
    };
  }
  async queryVideos(endpoint, langCode) {
    if (!this.apiKey)
      return [];
    try {
      const res = await fetch(this.getUrl(endpoint, {
        include_video_language: `${langCode},en,null`
      }), {
        headers: this.getHeaders(),
        signal: AbortSignal.timeout(6000)
      });
      if (!res.ok)
        return [];
      const payload = await res.json();
      return parseVideoResults(payload);
    } catch {
      return [];
    }
  }
}

// plugins/trailers/src/trailers-manager.ts
var INDEX_KEY = "trailers_index";
var STATS_KEY = "trailers_stats";
function toStorageKey(prefix, rawKey) {
  const sanitized = rawKey.trim().toLowerCase().replace(/[^A-Za-z0-9._-]/g, "_");
  return `${prefix}_${sanitized}`.slice(0, 100);
}
function isRecord2(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isStringArray(value) {
  return Array.isArray(value) && value.every((item) => typeof item === "string");
}
function isTrailerInfo(value) {
  return isRecord2(value) && typeof value.trailerKey === "string" && (value.mediaType === "movie" || value.mediaType === "tv_show");
}
function isStatsMeta(value) {
  return isRecord2(value) && (value.lastSyncAt === undefined || typeof value.lastSyncAt === "string");
}
function firstNonEmpty(...values) {
  return values.find((value) => value !== undefined && value !== "") ?? "";
}

class TrailersManager {
  host;
  tmdbClient;
  constructor(host, config) {
    this.host = host;
    this.tmdbClient = new TmdbTrailersClient(config.apiKey, config.preferredLanguage);
  }
  async getTrailer(metadataId, options) {
    const context = await this.resolveContext(metadataId, options);
    if (!(context.title || context.tmdbId || metadataId)) {
      return null;
    }
    const cacheKey = this.buildCacheKey(metadataId, context.tmdbId, context.title);
    const storedCache = await this.host.storage.get(cacheKey);
    const cached = isTrailerInfo(storedCache) ? storedCache : null;
    if (cached) {
      return cached;
    }
    const trailer = await this.discoverTrailer(context, metadataId, cacheKey);
    return trailer;
  }
  async discoverTrailer(context, metadataId, cacheKey) {
    let tmdbId = context.tmdbId;
    let mediaType = context.mediaType;
    if (!tmdbId && context.title) {
      const searchResult = await this.tmdbClient.searchTmdbId(context.title, mediaType, context.year);
      if (searchResult) {
        tmdbId = searchResult.id;
        mediaType = searchResult.mediaType;
      }
    }
    if (!tmdbId) {
      return null;
    }
    const trailerResult = await this.tmdbClient.fetchTrailer(tmdbId, mediaType);
    if (!trailerResult) {
      return null;
    }
    const trailerInfo = {
      metadataId: metadataId ?? String(tmdbId),
      title: firstNonEmpty(context.title, trailerResult.name, "Zwiastun"),
      mediaType,
      trailerKey: trailerResult.key,
      trailerUrl: `https://www.youtube-nocookie.com/embed/${trailerResult.key}?autoplay=1&rel=0&modestbranding=1`,
      site: "YouTube",
      name: trailerResult.name,
      official: trailerResult.official,
      language: trailerResult.language,
      cachedAt: new Date().toISOString()
    };
    await this.host.storage.set(cacheKey, trailerInfo);
    if (metadataId) {
      await this.addToIndex(metadataId);
    }
    return trailerInfo;
  }
  async resolveContext(metadataId, options) {
    let title = options?.title?.trim();
    let mediaType = options?.mediaType === "tv_show" ? "tv_show" : "movie";
    let tmdbId = options?.tmdbId;
    let year = options?.year;
    if (metadataId) {
      try {
        const metadata = await this.host.metadata.get(metadataId);
        if (metadata) {
          title = metadata.title || title;
          mediaType = metadata.type === "tv_show" ? "tv_show" : "movie";
          if (metadata.releaseDate) {
            const parsedYear = new Date(metadata.releaseDate).getFullYear();
            if (!Number.isNaN(parsedYear))
              year = parsedYear;
          }
          if (!tmdbId) {
            const tmdbExt = metadata.externalIds.find((e) => e.providerId === "tmdb");
            if (tmdbExt?.externalId) {
              const parsed = Number(tmdbExt.externalId);
              if (!Number.isNaN(parsed))
                tmdbId = parsed;
            }
          }
        }
      } catch (err) {
        this.host.logger.warn("Failed to query host.metadata.get for trailer discovery", {
          metadataId,
          err: err instanceof Error ? err.message : String(err)
        });
      }
    }
    return { title, mediaType, tmdbId, year };
  }
  buildCacheKey(metadataId, tmdbId, title) {
    if (metadataId)
      return toStorageKey("trailer_meta", metadataId);
    if (tmdbId)
      return toStorageKey("trailer_tmdb", String(tmdbId));
    return toStorageKey("trailer_title", title ?? "");
  }
  async getStats() {
    const storedIndex = await this.host.storage.get(INDEX_KEY);
    const index = isStringArray(storedIndex) ? storedIndex : [];
    let moviesCount = 0;
    let showsCount = 0;
    for (const id of index) {
      const storedItem = await this.host.storage.get(toStorageKey("trailer_meta", id));
      const item = isTrailerInfo(storedItem) ? storedItem : null;
      if (item) {
        if (item.mediaType === "movie")
          moviesCount++;
        else
          showsCount++;
      }
    }
    const storedStats = await this.host.storage.get(STATS_KEY);
    const statsMeta = isStatsMeta(storedStats) ? storedStats : undefined;
    return {
      cachedCount: index.length,
      moviesCount,
      showsCount,
      lastSyncAt: statsMeta?.lastSyncAt
    };
  }
  async bulkCache(items) {
    let processed = 0;
    let discovered = 0;
    const targetItems = items ?? [];
    for (const item of targetItems) {
      if (!item.id)
        continue;
      processed++;
      const storedExisting = await this.host.storage.get(toStorageKey("trailer_meta", item.id));
      const existing = isTrailerInfo(storedExisting) ? storedExisting : null;
      if (existing) {
        continue;
      }
      const trailer = await this.getTrailer(item.id, {
        title: item.title,
        mediaType: item.type === "tv_show" ? "tv_show" : "movie",
        tmdbId: item.tmdbId
      });
      if (trailer) {
        discovered++;
      }
      await new Promise((resolve) => {
        setTimeout(resolve, 100);
      });
    }
    await this.host.storage.set(STATS_KEY, { lastSyncAt: new Date().toISOString() });
    return { processed, discovered };
  }
  async addToIndex(metadataId) {
    const storedIndex = await this.host.storage.get(INDEX_KEY);
    const index = isStringArray(storedIndex) ? storedIndex : [];
    if (!index.includes(metadataId)) {
      index.push(metadataId);
      await this.host.storage.set(INDEX_KEY, index);
    }
  }
}

// plugins/trailers/index.ts
function isRecord3(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function parseBulkCacheItems(body) {
  if (!Array.isArray(body))
    return;
  const items = [];
  for (const entry of body) {
    if (!isRecord3(entry) || typeof entry.id !== "string")
      continue;
    items.push({
      id: entry.id,
      ...typeof entry.title === "string" ? { title: entry.title } : {},
      ...entry.type === "movie" || entry.type === "tv_show" ? { type: entry.type } : {},
      ...typeof entry.tmdbId === "number" ? { tmdbId: entry.tmdbId } : {}
    });
  }
  return items;
}
var TrailerQuery = t.Object({
  metadataId: t.Optional(t.String()),
  title: t.Optional(t.String()),
  mediaType: t.Optional(t.Union([t.Literal("movie"), t.Literal("tv_show")])),
  tmdbId: t.Optional(t.String()),
  year: t.Optional(t.String())
});
var trailers_default = definePlugin(config, {
  async setup(host) {
    const manager = new TrailersManager(host, host.config);
    host.logger.info("Trailers plugin initialized", {
      preferredLanguage: host.config.preferredLanguage
    });
    await host.routes.register(route({
      method: "GET",
      path: "/trailer",
      query: TrailerQuery,
      handler: async ({ query }) => {
        const metadataId = query.metadataId ?? "";
        const mediaType = query.mediaType ?? "movie";
        const tmdbId = query.tmdbId !== undefined ? Number(query.tmdbId) : undefined;
        const year = query.year !== undefined ? Number(query.year) : undefined;
        if (!(metadataId || query.title || tmdbId)) {
          return ok({ error: "metadataId, title or tmdbId is required." });
        }
        const trailer = await manager.getTrailer(metadataId, {
          tmdbId,
          title: query.title,
          mediaType,
          year
        });
        if (!trailer) {
          return ok({ found: false, message: "No trailer found for this title." });
        }
        return ok({ found: true, ...trailer });
      }
    }));
    await host.routes.register({
      method: "GET",
      path: "/stats",
      handler: async () => {
        const stats = await manager.getStats();
        return ok({
          ...stats,
          config: { preferredLanguage: host.config.preferredLanguage }
        });
      }
    });
    await host.routes.register({
      method: "POST",
      path: "/cache-all",
      access: "admin",
      handler: async ({ body }) => {
        const items = parseBulkCacheItems(body);
        const result = await manager.bulkCache(items);
        return ok({ success: true, ...result });
      }
    });
  }
});
export {
  trailers_default as default
};
